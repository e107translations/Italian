<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/12 15:39:55
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/
define("LAN_THEMEPREF_00", "Marchio:");
define("LAN_THEMEPREF_01", "Allineamento Barra di Navigazione:");
define("LAN_THEMEPREF_02", "Posizione Registrazione/Autenticazione");
define("LAN_THEMEPREF_03", "Style Bootswatch:");
define("LAN_THEMEPREF_04", "Nome Sito web");
define("LAN_THEMEPREF_05", "Logo");
define("LAN_THEMEPREF_06", "Logo & Nome Sito web");
define("LAN_THEMEPREF_07", "Sinistra");
define("LAN_THEMEPREF_08", "Destra");
define("LAN_THEMEPREF_09", "Sopra");
define("LAN_THEMEPREF_10", "Sotto");


?>