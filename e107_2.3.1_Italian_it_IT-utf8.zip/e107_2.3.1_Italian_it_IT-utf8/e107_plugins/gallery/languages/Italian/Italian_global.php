<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/11 13:55:58
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_GALLERY_TITLE", "Galleria");
define("LAN_PLUGIN_GALLERY_DIZ", "Una galleria di immagini semplice");
define("LAN_PLUGIN_GALLERY_SEF_01", "Galleria indirizzo Amichevole (SEF)");
define("LAN_PLUGIN_GALLERY_SEF_02", "URLs Amichevoli (SEF) abilitati");
define("LAN_PLUGIN_GALLERY_SEF_03", "URL Amichevole (SEF) disabilitato");
define("LAN_PLUGIN_GALLERY_SEF_04", "Galleria di Default");


?>