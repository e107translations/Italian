<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/11 00:15:53
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("LAN_GALLERY_FRONT_01", "Click Tasto destro Salva il Link a");
define("LAN_GALLERY_FRONT_02", "espandi l'immagine");


?>