<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("NFPM_LAN_1", "Thread");
define("NFPM_LAN_2", "Poster");
define("NFPM_LAN_3", "Visualizzazioni");
define("NFPM_LAN_4", "Risposte");
define("NFPM_LAN_5", "Lastpost");
define("NFPM_LAN_6", "Discussioni");
define("NFPM_LAN_7", "da");
define("NFPM_L1", "Questo plugin consente di visualizzare un elenco di nuovi messaggi nel forum sulla vostra prima pagina");
define("NFPM_L2", "Ultimi messaggi del Forum");
define("NFPM_L3", "Per configurare per favore clicca sul link nella sezione plugin di admin prima pagina");
define("NFPM_L4", "Attivare in quale zona?");
define("NFPM_L5", "Inattivo");
define("NFPM_L6", "Parte superiore della pagina");
define("NFPM_L7", "Fondo pagina");
define("NFPM_L8", "Didascalia");
define("NFPM_L9", "Numero di nuovi messaggi da visualizzare?");
define("NFPM_L10", "Visualizzare all'interno di strato di scorrimento?");
define("NFPM_L11", "Strato di altezza");
define("NFPM_L12", "Nuova configurazione di post del Forum");
define("NFPM_L13", "Nuove impostazioni Forum Post aggiornate.");
define("NFPM_L14", "Visualizza ultimi messaggi del forum?");
define("NFPM_L15", "Per impostazione predefinita, vengono visualizzati gli ultimi argomenti.");
define("NFPM_L16", "[utente cancellato]");
define("NFPM_L17", "Nuovi messaggi sul Thread popolare");
define("NFPM_L18", "Nuovi post");
define("NFPM_L19", "No nuovi messaggi sul Thread popolare");
define("NFPM_L20", "Nessun nuovo post");
define("NFPM_L21", "Thread Sticky");
define("NFPM_L22", "Chiuso il Thread Sticky");
define("NFPM_L23", "Annuncio");
define("NFPM_L24", "Discussione chiusa");
