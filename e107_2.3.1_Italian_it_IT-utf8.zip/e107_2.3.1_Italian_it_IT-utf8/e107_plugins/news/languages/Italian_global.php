<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2021/03/14 01:51:43
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_NEWS_NAME", "Notizie");
