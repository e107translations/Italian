<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/11 01:03:26
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/
define("LAN_NEWS_ADMIN_00", "Ultime Notizie");
define("LAN_NEWS_ADMIN_01", "Notizie Appiccicose");
define("LAN_NEWS_ADMIN_02", "Notizie Assegnate");
define("LAN_NEWS_ADMIN_03", "Limitare le notizie alla specifica categoria");
define("LAN_NEWS_ADMIN_04", "Le Voci interessate sono quelle assegnate a 'Notizie  Menù Griglia'");
define("LAN_NEWS_ADMIN_05", "Numero Notizie da Visualizzare");
define("LAN_NEWS_ADMIN_06", "Limite Caratteri Titolo");
define("LAN_NEWS_ADMIN_07", "Riassunto Limite Caratteri");
define("LAN_NEWS_ADMIN_08", "Visualizza l'Archivio dei Link");
define("LAN_NEWS_ADMIN_09", "Limiti");
define("LAN_NEWS_ADMIN_10", "Numero di Funzione Elementi");
define("LAN_NEWS_ADMIN_11", "Le Voci interessate sono quelle assegnate a 'Notizie Carousel'");


?>