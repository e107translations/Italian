<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2018/09/13 13:56:48
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("TD_MENU_L1", "Altre Notizie");
define("TD_MENU_L2", "Altre Notizie");
define("LAN_NEWSCAT_MENU_TITLE", "Categorie Notizie");
define("LAN_NEWSLATEST_MENU_TITLE", "Ultime Notizie");
define("LAN_NEWSARCHIVE_MENU_TITLE", "Archivio Notizie");
