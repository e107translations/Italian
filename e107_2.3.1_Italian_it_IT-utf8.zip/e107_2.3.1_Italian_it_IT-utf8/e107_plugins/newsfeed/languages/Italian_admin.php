<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/11 00:21:02
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/
define("NFLAN_11", "Percorso immagine");
define("NFLAN_12", "Attivazione");
define("NFLAN_13", "Nulla (inattivo)");
define("NFLAN_14", "Solo nel menu");
define("NFLAN_18", "Intervallo di aggiornamento in secondi");
define("NFLAN_19", "ad esempio 3600: newsfeed verrà aggiornata ogni ora");
define("NFLAN_20", "Solo la pagina principale di newsfeed");
define("NFLAN_21", "Nella pagina sia menu e newsfeed");
define("NFLAN_26", "Intervallo di aggiornamento");
define("NFLAN_43", "Guida di newsfeed");
define("NFLAN_42", "[h=4]Titolo feed:[/h]
	Il nome che identifica il feed può essere inserito a tuo piacimento.<br>
	[h=4]URL al FEED RSS:[/h] L'indirizzo URL del feed rss da dove desideri prelevare le notizie. <br>[h=4]Percorso Immagine[/h]Se il feed contiene un'immagine definita in esso, immettere 'default' per utilizzarla. Per scegliere ed utilizzare una tua immagine personale inserisci l'indirizzo dell'immagine. Lascia in bianco per non utilizzare nessuna immagine<br>[h=4]Descrizione[/h] inserisci una breve descrizione del feed oppure 'default' per usare la descrizione predefinita nel feed (se presente).[br][h=4]Aggiorna Intervallo[/h]Inserisci il numero dei seondi prima che il feed rss sia aggiornato. Per esempio, 1800 per 30 Minuti, 3600 per 1 Ora86400 per 1 Giorno.[h=4]Attivazione[/h] I Feed Notizie possono essere visualizzate solo nel menù oppure nella pagina newsfeed. specifica dove i Newsfeed devono essere visualizzati. Per visualizzare i newsfeed nei menu di e107 tu puoi attivarli in [b]Newsfeeds Menu[/b] su
[link=".e_ADMIN."menus.php]Menu Manager[/link]. [h=4]Tip[/h] There are many feed direcotries on the web, try [link=https://www.dmoz.org/Computers/Internet/On_the_Web/Syndication_and_Feeds/RSS/Directories/ external]dmoz[/link] or [link=http://www.feedster.com/ external]feedster.com[/link]");
define("NFLAN_45", "Numero di elementi da visualizzare nel menu");
define("NFLAN_46", "Numero di elementi da visualizzare nella pagina principale");


?>