<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/12 15:11:35
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_NEWSFEEDS_NAME", "Feed Notizie");
define("LAN_PLUGIN_NEWSFEEDS_DESCRIPTION", "Questo plugin sarà recuperare i feed rss da altri siti Web e li visualizza in base alle vostre preferenze.");


?>