<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("CHBLAN_11", "Chatbox messaggi da visualizzare");
define("CHBLAN_12", "Quantità di post visualizzati in chatbox");
define("CHBLAN_20", "Impostazioni chat");
define("CHBLAN_22", "Eliminare i messaggi più vecchi di un certo periodo di tempo");
define("CHBLAN_23", "Eliminare i messaggi più vecchi di");
define("CHBLAN_24", "Un giorno");
define("CHBLAN_25", "Una settimana");
define("CHBLAN_26", "Un mese");
define("CHBLAN_27", "-Elimina tutti i messaggi-");
define("CHBLAN_29", "Visualizzare la chat all'interno di scorrimento strato con altezza [x]");
define("CHBLAN_31", "Mostra emoticon");
define("CHBLAN_32", "Moderatore ClasseUtente");
define("CHBLAN_33", "Numero di utenti ricalcolato");
define("CHBLAN_34", "Ricalcolare il numero di post di utenti");
define("CHBLAN_35", "Ricalcola");
define("CHBLAN_36", "Opzioni di visualizzazione ChatBox");
define("CHBLAN_37", "Chatbox normale");
define("CHBLAN_38", "Utilizzare codice javascript per aggiornare tutti i messaggi in modo dinamico (AJAX)");
define("CHBLAN_42", "Visualizza la quantità di messaggi nel profilo utente");
