<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/10 23:46:47
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/
define("CHATBOX_L1", "Incapace di accettare il posto come tale nome utente è registrato - se è il tuo nome utente effettua il login per postare.");
define("CHATBOX_L3", "Devi essere loggato per inviare commenti su questo sito - per favore login o se non sei registrato clicca [qui] per iscriverti");
define("CHATBOX_L3b", "Non risulti registrato premi [qui] per procedere alla registrazione");
define("CHATBOX_L4", "Nuovo messaggio di posta");
define("CHATBOX_L5", "Reset");
define("CHATBOX_L6", "[bloccato dall'admin]");
define("CHATBOX_L7", "Sbloccare");
define("CHATBOX_L8", "Info");
define("CHATBOX_L9", "Blocco");
define("CHATBOX_L11", "Messaggi non ancora.");
define("CHATBOX_L12", "Visualizza tutti i post");
define("CHATBOX_L13", "chatbox moderata");
define("CHATBOX_L14", "EMote");
define("CHATBOX_L15", "Post troppo lunghi o vuoto post presentato");
define("CHATBOX_L17", "Post duplicato");
define("CHATBOX_L18", "Messaggi di ChatBox moderati");
define("CHATBOX_L19", "Puoi solo pubblicare una volta ogni [x] secondi");
define("CHATBOX_L20", "Chatbox (tutti i messaggi)");
define("CHATBOX_L22", "il");
define("CHATBOX_L24", "Non si dispone delle autorizzazioni corrette per visualizzare questa pagina.");
define("CHATBOX_L25", "[questo post è stato bloccato da admin]");
define("LAN_CHATBOX_100", "Digita qui il tuo messaggio.");
