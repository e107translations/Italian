<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_PLUGIN_CHATBOX_MENU_NAME", "ChatBox");
define("LAN_PLUGIN_CHATBOX_MENU_DESCRIPTION", "Chatbox Menu");
define("LAN_PLUGIN_CHATBOX_MENU_POSTS", "Chatbox post");
define("LAN_AL_CHBLAN_01", "Chatbox impostazioni aggiornate");
define("LAN_AL_CHBLAN_02", "Chatbox potato");
define("LAN_AL_CHBLAN_03", "Chatbox post ricalcolato");
define("LAN_AL_CHBLAN_04", "");
define("LAN_AL_CHBLAN_05", "");
define("NT_LAN_CB_1", "Chatbox eventi");
define("NT_LAN_CB_2", "Messaggio inviato");
define("NT_LAN_CB_3", "Inviato da");
define("NT_LAN_CB_5", "Messaggio");
define("NT_LAN_CB_6", "Chatbox messaggio inviato");
