<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("XMLRPC_ADMIN_001", "Menu principale");
define("XMLRPC_CONFIG_001", "MetaWeblog:: configurazione");
define("XMLRPC_PREFS_001", "eXMLRPC - opzioni");
define("XMLRPC_PREFS_002", "eXMLRPC");
define("XMLRPC_PREFS_003", "Tipo di rendering di notizie (0,1,2,3)");
define("XMLRPC_PREFS_004", "Caricare directory (e_FILE /)");
define("XMLRPC_PREFS_005", "ID del Blog per client");
define("XMLRPC_PREFS_006", "Nome del Blog per client");
define("XMLRPC_HELP_001", "Istruzioni");
define("XMLRPC_HELP_010", "Generale");
define("XMLRPC_HELP_011", "Questo plugin stesso non fa niente! È solo per impostazioni alcuni varibles XMLRPC. Il vostro client XMLRPC (es: Windows Live Writer) a <strong>'. SITEURL.' MetaWeblog.php</strong> e compilare i valori richiesti. Attenzione! Questo plugin è in fase sperimentale!");
define("XMLRPC_HELP_020", "Titolo di plugin");
define("XMLRPC_HELP_021", "Non importa plugin non uscita");
define("XMLRPC_HELP_030", "Tipo di rendering notizie");
define("XMLRPC_HELP_031", "Importante! Tipo di rendering predefinito notizie");
define("XMLRPC_HELP_040", "Caricare la cartella per i file");
define("XMLRPC_HELP_041", "È sempre una cartella all'interno di e107_files!");
define("XMLRPC_HELP_050", "ID del Blog per client");
define("XMLRPC_HELP_051", "Id del Blog per client XMLRPC (qualsiasi stringa che si desidera)");
define("XMLRPC_HELP_060", "Nome del Blog per client");
define("XMLRPC_HELP_061", "Nome del Blog per client XMLRPC (qualsiasi stringa che si desidera)");
