<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2018/09/13 14:12:32
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("NLLAN_04", "Il newsletter plugin è stato installato con successo. Per configurare, tornare alla pagina principale admin e cliccare su \'Newsletter\' nella sezione plugin.");
define("NLLAN_05", "Nessuna newsletter ancora definita");
define("NLLAN_07", "Abbonati");
define("NLLAN_10", "Newsletters esistente");
define("NLLAN_11", "Nessun problema di newsletter ancora.");
define("NLLAN_12", "Problema");
define("NLLAN_13", "[ID principale] Oggetto/titolo");
define("NLLAN_14", "Spedita?");
define("NLLAN_17", "Non inviati - Clicca per inviare");
define("NLLAN_18", "Sei sicuro che vuoi questo problema di posta agli abbonati?");
define("NLLAN_19", "Sei sicuro di che voler eliminare questo numero della newsletter?");
define("NLLAN_20", "Problemi esistenti");
define("NLLAN_23", "Intestazione");
define("NLLAN_24", "Piè di pagina");
define("NLLAN_30", "Newsletter");
define("NLLAN_31", "Oggetto / titolo");
define("NLLAN_32", "Numero di emissione");
define("NLLAN_33", "Testo");
define("NLLAN_36", "Numero della Newsletter di aggiornamento");
define("NLLAN_37", "Creare Newsletter edizione");
define("NLLAN_39", "Newsletter edizione salvato nel database - per l'invio, fare clic il \'Release Issue\' pulsante nel menu opzioni.");
define("NLLAN_40", "La Posta in uscita è stata aggiunta alla coda email - pubblicazione inviata  a [x] abbonati");
define("NLLAN_41", "Non trovati sottosxcrittori - e-mail cancellata");
define("NLLAN_44", "Prima pagina newsletter");
define("NLLAN_45", "Creare Newsletter");
define("NLLAN_46", "Creare Mailing");
define("NLLAN_47", "Opzioni newsletter");
define("NLLAN_48", "Abbonati alla newsletter");
define("NLLAN_49", "Newsletter:");
define("NLLAN_54", "L'invio di");
define("NLLAN_56", "Newsletter ID non disponibile");
define("NLLAN_62", "Utente è vietato! (o non completamente firmato fino)");
define("NLLAN_63", "Totale utenti abbonati");
define("NLLAN_64", "Tornare alla pagina principale della Newsletter");
define("NLLAN_65", "Visualizza Panoramica newsletter  ID");
define("NLLAN_66", "La tua lista di abbonati è stata ripulita");
