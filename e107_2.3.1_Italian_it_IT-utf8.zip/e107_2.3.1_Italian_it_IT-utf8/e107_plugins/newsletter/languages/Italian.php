<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/11 00:23:54
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("NLLAN_MENU_CAPTION", "Newsletter");
define("NLLAN_48", "Sei iscritto a questa newsletter - se vuoi cancellarti clicca il pulsante qui sotto.");
define("NLLAN_49", "Sei sicuro di voler ONU-iscriverti a questa newsletter?");
define("NLLAN_50", "Fare clic sul pulsante per iscriversi (il tuo indirizzo di sottoscrizione è");
define("NLLAN_51", "Annullare l'iscrizione");
define("NLLAN_52", "Abbonarsi");
define("NLLAN_53", "Sei sicuro che vuoi iscriverti a questa newsletter?");
define("NLLAN_67", "Panoramica di archivio");
define("NLLAN_68", "Parametro non valido definito");
define("NLLAN_69", "Nessuna newsletter inviate disponibile.");
define("NLLAN_70", "Newsletter selezionata non esiste");
define("NLLAN_72", "Visualizza l'archivio");
define("NLLAN_73", "Inserisci la tua Email");


?>