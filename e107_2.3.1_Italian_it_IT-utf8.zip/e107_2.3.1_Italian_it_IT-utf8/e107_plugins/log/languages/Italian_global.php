<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_PLUGIN_LOG_NAME", "Statistiche del sito");
define("LAN_PLUGIN_LOG_DESCRIPTION", "Questo plugin sarà accedere tutte le visite al tuo sito e costruire schermi di statistica dettagliata sulla base delle informazioni raccolte.");
define("LAN_PLUGIN_LOG_CONFIGURE", "Configurare la registrazione delle statistiche");
define("LAN_PLUGIN_LOG_LINK", "Visite");
