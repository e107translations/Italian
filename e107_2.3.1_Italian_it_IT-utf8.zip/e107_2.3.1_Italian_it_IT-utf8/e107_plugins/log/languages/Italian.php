<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/11/07 23:21:53
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "Statistiche");
define("ADSTAT_L1", "Questo plugin sarà accedere tutte le visite al tuo sito e costruire schermi di statistica dettagliata sulla base delle informazioni raccolte.");
define("ADSTAT_L2", "Il logger di statistiche è stato installato correttamente. Per convertire le statistiche esistenti al nuovo sistema, si prega di <a href=''.e_PLUGIN.'log/update_routine.php'>cliccare qui per eseguire la routine di aggiornamento</a>.");
define("ADSTAT_L3", "Registrazione statistica");
define("ADSTAT_L4", "Non si dispone dell'autorizzazione per visualizzare questa pagina.");
define("ADSTAT_L5", "Le caratteristiche in questa pagina sono state disattivate.");
define("ADSTAT_L6", "Statistiche del sito");
define("ADSTAT_L7", "Non vengono raccolte statistiche per questo tipo.");
define("ADSTAT_L8", "Statistiche di oggi");
define("ADSTAT_L9", "Statistiche di tutti i tempi");
define("ADSTAT_L10", "Statistiche giornaliere");
define("ADSTAT_L11", "Statistiche mensili");
define("ADSTAT_L12", "Statistiche di browser");
define("ADSTAT_L13", "Statistiche di sistema operativo");
define("ADSTAT_L14", "Statistiche del dominio");
define("ADSTAT_L15", "Risoluzione dello schermo / statistiche di profondità di colore");
define("ADSTAT_L16", "Statistiche di rinvio");
define("ADSTAT_L17", "Statistiche di ricerca stringa");
define("ADSTAT_L18", "Visitatori recenti");
define("ADSTAT_L19", "Pagina");
define("ADSTAT_L20", "Visite oggi");
define("ADSTAT_L21", "Totale");
define("ADSTAT_L22", "Unico");
define("ADSTAT_L23", "Totale visite");
define("ADSTAT_L24", "Totale visitatori unici");
define("ADSTAT_L25", "Nessuna statistica disponibile.");
define("ADSTAT_L26", "Browser");
define("ADSTAT_L27", "Sistema operativo");
define("ADSTAT_L28", "Paesi / domini");
define("ADSTAT_L29", "Risoluzione dello schermo");
define("ADSTAT_L30", "Sito rinvii");
define("ADSTAT_L31", "Stringhe di Query di ricerca motore");
define("ADSTAT_L32", "Di cui da");
define("ADSTAT_L33", "Visite negli ultimi");
define("ADSTAT_L34", "Visite");
define("ADSTAT_L35", "Visite uniche in ultimo");
define("ADSTAT_L36", "giorni di pagina");
define("ADSTAT_L37", "Visite per mese");
define("ADSTAT_L38", "Visite uniche di mese");
define("ADSTAT_L39", "rimuovere questa voce");
define("ADSTAT_L40", "giorni");
define("ADSTAT_L42", "Nessuna statistica mensile ancora.");
define("ADSTAT_L43", "Errori di pagina di oggi");
define("ADSTAT_L44", "Errori di pagina di tutti i tempi");
define("ADSTAT_L45", "Statistiche eliminati per:");
define("ADSTAT_L46", "Nota: eventuali statistiche per oggi non verranno eliminati");
define("ADSTAT_L47", "Nessuna statistica trovata per:");
define("ADSTAT_L48", "ordinare da totale");
define("ADSTAT_L49", "ordinare in ordine alfabetico");
define("ADSTAT_L50", "Statistiche di tutti i tempi");
define("ADSTAT_L51", "Statistiche del mese corrente");
define("ADSTAT_L52", "Statistiche del mese precedente");
define("ADSTAT_L53", "Informazione");
define("ADSTAT_L54", "");
define("ADSTAT_L55", "");
define("ADSTAT_L56", "");
define("ADSTAT_L57", "");
define("ADSTAT_L58", "");
define("ADSTAT_L59", "");
define("ADSTAT_L60", "");


?>