<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_AL_STAT_01", "Statistiche - reset");
define("LAN_AL_STAT_02", "Statistiche - impostazioni modificate");
define("LAN_AL_STAT_03", "Statistiche - pagine rimosse");
define("LAN_AL_STAT_04", "Statistiche - dati storici rimossi");
