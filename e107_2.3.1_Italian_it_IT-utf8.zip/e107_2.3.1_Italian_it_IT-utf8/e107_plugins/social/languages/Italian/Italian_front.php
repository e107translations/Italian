<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - 
|     social plugin

+----------------------------------------------------------------------------+
*/
define("LAN_SOCIAL_000", "Condividi Su [x]");
define("LAN_SOCIAL_001", "Like su [x]");
define("LAN_SOCIAL_002", "Email a qualcuno");
define("LAN_SOCIAL_003", "+1 su Google");
define("LAN_SOCIAL_004", "Aggiungi a [x]");
define("LAN_SOCIAL_005", "Guarda questo link:");
define("LAN_SOCIAL_100", "Impossibile visualizzare feed. Facebook App ID non è stato definito nelle preferenze.");
define("LAN_SOCIAL_200", "Disabilita la visualizzazione dei feed. L'URL di Twitter non è stato definito nelle preferenze.");
define("LAN_SOCIAL_201", "Tweets da");
define("LAN_SOCIAL_202", "Post su Twitter");
define("LAN_SOCIAL_203", "Scrivi il tuo tweet qui.");
define("LAN_SOCIAL_204", "Condividi");
define("LAN_SOCIAL_205", "IMpossibile visualizzare i messaggi manca l'AppID di Facebook");
define("LAN_SOCIAL_WARNING", "Commentare su Facebook richiede che si disponga di un AppID di Facebook. Vai in admin-preferenze 'login social' ed aggiugine uno.");


?>