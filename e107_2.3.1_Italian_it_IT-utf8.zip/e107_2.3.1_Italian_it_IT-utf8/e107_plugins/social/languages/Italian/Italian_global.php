<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - 
|     social plugin

+----------------------------------------------------------------------------+
*/
define("LAN_SOCIAL_ADMIN_SUMM", "Aggiunge Facebook, Twitter e altri widget di social media a e107. ");
define("LAN_PLUGIN_SOCIAL_DESCR", "Aggiunge le opzioni per sostituire il commento del motore e107 con Facebook. Aggiungi feed Twitter al tuo sito. etc.");
define("LAN_PLUGIN_SOCIAL_SIGNIN", "Accedi con:");
define("LAN_PLUGIN_SOCIAL_XUP_SIGNUP", "Accedi con il tuo [x] account");
define("LAN_PLUGIN_SOCIAL_XUP_REG", "Registati con il tuo [x] account");
define("LAN_PLUGIN_SOCIAL_NAME", "Social");
