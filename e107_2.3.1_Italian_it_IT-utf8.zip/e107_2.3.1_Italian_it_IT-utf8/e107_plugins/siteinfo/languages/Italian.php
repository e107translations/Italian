<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("COMPLIANCE_L1", "Conformità W3C");
define("SITEBUTTON_MENU_L1", "Link a noi");
define("POWEREDBY_L1", "Promosso da");
define("COUNTER_L1", "Visite di admin non sono contate.");
define("COUNTER_L2", "Questa pagina oggi...");
define("COUNTER_L3", "totale");
define("COUNTER_L4", "Questa pagina è mai...");
define("COUNTER_L5", "unico");
define("COUNTER_L6", "Sito...");
define("COUNTER_L7", "Contatore");
define("COUNTER_L8", "Messaggio di admin: <b>Stat registrazione è disabilitata.</b><br>Per attivare, è necessario installare il plugin di registrazione statistica dal tuo <a href=''.e_ADMIN.'plugin.php'>gestore dei plugin</a>, quindi attivarlo dalla <a href=''.e_PLUGIN.'log/admin_config.php'>schermata di configurazione</a>.");
