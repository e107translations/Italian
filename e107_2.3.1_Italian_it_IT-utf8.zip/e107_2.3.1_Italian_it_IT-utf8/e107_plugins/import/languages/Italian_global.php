<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_PLUGIN_IMPORT_NAME", "Importare in e107");
define("LAN_PLUGIN_IMPORT_DESCRIPTION", "Importare dati da Wordpress, Joomla, Drupal, Blogpost, RSS e altri formati.");
