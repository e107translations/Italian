<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2021/03/14 01:46:04
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_HERO_NAME", "Hero");
define("LAN_PLUGIN_HERO_SUMMARY", "Home page Gestione area 'Hero' ");
define("LAN_PLUGIN_HERO_DESCRIPTION", "Un'immagine e un cursore di testo con elenchi puntati animati per l'hero area della tua home page. ");
