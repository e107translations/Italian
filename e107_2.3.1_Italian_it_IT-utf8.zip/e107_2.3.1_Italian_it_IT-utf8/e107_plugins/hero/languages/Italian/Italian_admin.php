<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2021/03/14 01:44:54
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("LAN_HERO_ADMIN_001", "Slides predefinite importate. ");
define("LAN_HERO_ADMIN_002", "Errore nell'importazione delle slides predefinite");
define("LAN_HERO_ADMIN_003", "Background - Sfondo");
define("LAN_HERO_ADMIN_004", "Immagine/Video");
define("LAN_HERO_ADMIN_005", "Media");
define("LAN_HERO_ADMIN_006", "etichetta");
define("LAN_HERO_ADMIN_007", "Assicurati di abilitare il menu Hero sulla tua home page utilizzando [Menu Manager]. ");
define("LAN_HERO_ADMIN_009", "pacchetto icone");
define("LAN_HERO_ADMIN_010", "stile icone");
define("LAN_HERO_ADMIN_011", "Intervallo di scorrimento automatizzato");
define("LAN_HERO_ADMIN_012", "Testo");
define("LAN_HERO_ADMIN_013", "Animazione");
define("LAN_HERO_ADMIN_014", "Ritardo (sec)");
define("LAN_HERO_ADMIN_015", "Pulsante");
define("LAN_HERO_ADMIN_016", "[x] second(s)");
