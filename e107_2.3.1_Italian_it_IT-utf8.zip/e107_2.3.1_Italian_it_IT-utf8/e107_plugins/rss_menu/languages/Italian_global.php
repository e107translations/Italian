<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_PLUGIN_RSS_NAME", "RSS");
define("LAN_PLUGIN_RSS_DESCRIPTION", "I feed RSS dal tuo sito.");
define("LAN_PLUGIN_RSS_SUBSCRIBE", "Abbonarsi");
define("LAN_PLUGIN_RSS_SUBSCRIBE_TO", "Abbonarsi a [x]");
