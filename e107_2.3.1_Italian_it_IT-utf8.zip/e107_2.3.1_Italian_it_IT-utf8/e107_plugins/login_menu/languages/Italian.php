<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_LOGINMENU_1", "Nome utente:");
define("LAN_LOGINMENU_2", "Password:");
define("LAN_LOGINMENU_3", "Registrati");
define("LAN_LOGINMENU_4", "Dimenticato la password?");
define("LAN_LOGINMENU_5", "Benvenuto");
define("LAN_LOGINMENU_6", "Ricordati di me");
define("LAN_LOGINMENU_7", "ID utente univoco non riconosciuto (possibili cookie danneggiato). Cliccate sul collegamento logout per distruggere cookie.");
define("LAN_LOGINMENU_9", "Errore di login");
define("LAN_LOGINMENU_10", "La bandiera di manutenzione è vera - questo significa normali visitatori vengono reindirizzati a sitedown.php. Per reimpostare il flag Vai alla admin/manutenzione.");
define("LAN_LOGINMENU_11", "Area Admin");
define("LAN_LOGINMENU_13", "Profilo");
define("LAN_LOGINMENU_14", "notizia");
define("LAN_LOGINMENU_15", "articoli di notizie");
define("LAN_LOGINMENU_16", "Chatbox post");
define("LAN_LOGINMENU_17", "Chatbox post");
define("LAN_LOGINMENU_18", "Commento");
define("LAN_LOGINMENU_19", "Commenti");
define("LAN_LOGINMENU_20", "post nel forum");
define("LAN_LOGINMENU_21", "messaggi nel forum");
define("LAN_LOGINMENU_22", "nuovo membro del sito");
define("LAN_LOGINMENU_23", "nuovi membri del sito");
define("LAN_LOGINMENU_24", "Clicca qui per vedere l'elenco dei nuovi elementi");
define("LAN_LOGINMENU_25", "Dalla tua ultima visita ci sono stati");
define("LAN_LOGINMENU_26", "No");
define("LAN_LOGINMENU_27", "e");
define("LAN_LOGINMENU_31", "Visualizza nuovi messaggi di News");
define("LAN_LOGINMENU_34", "Visualizza nuovi messaggi di commento");
define("LAN_LOGINMENU_36", "Visualizza nuovi membri");
define("LAN_LOGINMENU_39", "Lascia Admin");
define("LAN_LOGINMENU_40", "Reinvia Email attivazione");
define("LAN_LOGINMENU_41", "Impostazioni di Menu login");
define("LAN_LOGINMENU_37", "Visualizza");
define("LAN_LOGINMENU_38", "Menu di login - collegamenti aggiuntivi");
define("LAN_LOGINMENU_42", "Menu di login - aggiunte recenti core");
define("LAN_LOGINMENU_43", "Posizione");
define("LAN_LOGINMENU_44", "titolo di missing link");
define("LAN_LOGINMENU_45", "link (s)-");
define("LAN_LOGINMENU_45a", "");
define("LAN_LOGINMENU_45b", "plugin");
define("LAN_LOGINMENU_46", "elementi recenti-");
define("LAN_LOGINMENU_47", "Menu di login - aggiunte recenti plugin");
define("LAN_LOGINMENU_48", "Dal menu Config");
define("LAN_LOGINMENU_49", "Posta elettronica:");
define("LAN_LOGINMENU_50", "Username o Email:");
define("LAN_LOGINMENU_51", "Accedi");
