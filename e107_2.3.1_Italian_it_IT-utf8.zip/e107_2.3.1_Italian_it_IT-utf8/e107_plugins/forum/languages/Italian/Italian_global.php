<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/11 00:14:34
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_FORUM_NAME", "Cose da fare");
define("LAN_PLUGIN_FORUM_DESC", "Questo plugin è un sistema di forum completamente descritto.");
define("LAN_PLUGIN_FORUM_POSTS", "Messaggi nel forum");
define("LAN_PLUGIN_FORUM_ALLFORUMS", "Tutti i forum");
define("LAN_PLUGIN_FORUM_LATESTPOSTS", "Ultimo Post");
define("FORUM_LAN_URL_DEFAULT_LABEL", "URL predefiniti in Forum");
define("FORUM_LAN_URL_DEFAULT_DESCR", "URL di 'GET tipo' con nessun singolo punto di ingresso. Esempi:<br>http://yoursite.com/e107_plugins/forum/forum.php (indice del forum)<br>http://yoursite.com/e107_plugins/Forum/forum_viewtopic.php?ID=2 (visualizzazione thread)");
define("FORUM_LAN_URL_REWRITE_LABEL", "SEF URL dei Forum (in sviluppo)");
define("FORUM_LAN_URL_REWRITE_DESCR", "Esempi:<br>IN FASE DI SVILUPPO");


?>