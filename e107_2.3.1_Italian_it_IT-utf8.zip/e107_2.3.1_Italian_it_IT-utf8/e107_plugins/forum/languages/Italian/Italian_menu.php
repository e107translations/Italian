<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2018/09/13 13:41:56
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/
define("LAN_FORUM_MENU_001", "Inviato da");
define("LAN_FORUM_MENU_002", "Ancora nessun post");
define("LAN_FORUM_MENU_003", "Nuova configurazione del menu messaggi del Forum salvata");
define("LAN_FORUM_MENU_004", "Didascalia");
define("LAN_FORUM_MENU_005", "Numero di messaggi da visualizzare?");
define("LAN_FORUM_MENU_006", "Numero di caratteri da visualizzare?");
define("LAN_FORUM_MENU_007", "Postfix per post troppo lunghi?");
define("LAN_FORUM_MENU_008", "Mostra argomenti originale nel menu?");
define("LAN_FORUM_MENU_009", "Aggiornare le impostazioni del menu");
define("LAN_FORUM_MENU_012", "Tempo massimo di visualizzazione messaggi");
define("LAN_FORUM_MENU_013", "Usa zero per un sito web poco frequentato, imposta il valore in giorni per ridurre il tempo di connessione al database in un sito molto frequentato.");
define("LAN_FORUM_MENU_014", "Altezza Livello scorrimento (in pixel)");
define("LAN_FORUM_MENU_015", "Lascia vuoto per nessuno scrolling");
define("LAN_FORUM_MENU_016", "Nessuna categoria forum creata ancora! ");
