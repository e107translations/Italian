<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2018/09/13 13:53:13
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("LAN_FORUM_NT_7", "Forum - Discussione creata da nuovo utente");
define("LAN_FORUM_NT_8", "Forum - Discussione eliminata");
define("LAN_FORUM_NT_9", "Forum - Discussione Tagliata");
define("LAN_FORUM_NT_10", "Forum - Post cancellato");
define("LAN_FORUM_NT_11", "Forum - Post segnalati");
define("LAN_FORUM_NT_12", "Forum - Discussione aggiornata");
define("LAN_FORUM_NT_13", "Forum - Discussione spostata");
define("LAN_FORUM_NT_14", "Forum - Post creato");
define("LAN_FORUM_NT_15", "Forum - Post aggiornato");
define("LAN_FORUM_NT_NEWTOPIC", "Creato un nuovo argomento");
define("LAN_FORUM_NT_NEWTOPIC_PROB", "Nuovo argomento creato utente di test");
define("LAN_FORUM_NT_TOPIC_SPLIT", "Argomento diviso");
define("LAN_FORUM_NT_TOPIC_UPDATED", "Argomento aggiornato");
define("LAN_FORUM_NT_TOPIC_DELETED", "Argomento eliminato");
define("LAN_FORUM_NT_TOPIC_MOVED", "Argomento spostato");
define("LAN_FORUM_NT_POST_CREATED", "Argomento creato");
define("LAN_FORUM_NT_POST_UPDATED", "Argomento aggiornato");
define("LAN_FORUM_NT_POST_DELETED", "Post eliminato");
define("LAN_FORUM_NT_POST_REPORTED", "Riportato il post");
define("LAN_FORUM_NT_NEWTOPIC_MSG", "Nuovo discussione nel forum [forum] creato da: [user]\nSubject:[thread]\n\nMessaggio:\n[post]");
define("LAN_FORUM_NT_NEWTOPIC_PROB_MSG", "Nuova discussione nel forum [forum] creato da un nuovo utente: [user]\nSubject:[thread]\n\nMessaggio:\n[post]");
define("LAN_FORUM_NT_TOPIC_UPDATED_MSG", "Discussione [thread] (Nome Forum: [forum] è stata appena aggiornata da: [user]");
define("LAN_FORUM_NT_TOPIC_DELETED_MSG", "Discussione [thread] nel forum [forum] è stata cancellata da: [user]");
define("LAN_FORUM_NT_TOPIC_MOVED_MSG", "Discussione [thread] è stata appena spostata da [forum] a al forum [forum2] da: [user] ");
define("LAN_FORUM_NT_POST_CREATED_MSG", "Nuovo messaggio nella discussione [thread] (Nome Forum: [forum] creato da: [user]\nMessaggio:\n[post]");
define("LAN_FORUM_NT_POST_UPDATED_MSG", "Il Messaggio nella discussione [threa] (Nome FORUM: [forum]) è stato aggiornato da: [user]\nMessaggio:\n[post]");
define("LAN_FORUM_NT_POST_DELETED_MSG", "Il Messaggio #[postid] della discussione [thread] nel forum [forum] è stato cancellato da: [user]\n\nMessaggio:\n[post]");
