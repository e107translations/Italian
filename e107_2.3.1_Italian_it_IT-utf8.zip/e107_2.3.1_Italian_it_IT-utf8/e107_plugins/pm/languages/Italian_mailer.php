<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2018/09/13 14:13:37
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("LAN_EC_PM_04", "Gestore di PM");
define("LAN_EC_PM_05", "Grande processo Invia di PMs");
define("LAN_EC_PM_06", "Avviare l'elaborazione di massa PM per [y] destinatari");
