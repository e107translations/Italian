<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_AL_PM_ADM_01", "PM: Prefs di Default utilizzato");
define("LAN_AL_PM_ADM_02", "PM: Prefs aggiornato");
define("LAN_AL_PM_ADM_03", "PM: DB manutenzione completa");
define("LAN_AL_PM_ADM_04", "PM: Manutenzione DB iniziato");
define("LAN_AL_PM_ADM_05", "PM: Limite aggiunto");
define("LAN_AL_PM_ADM_06", "PM: Limite aggiornato");
define("LAN_AL_PM_ADM_07", "PM: Limite cancellato");
define("LAN_AL_PM_ADM_08", "PM: Errore creazione di dati di limite");
define("LAN_AL_PM_ADM_09", "PM: Errore aggiornamento dei dati di limite");
define("LAN_AL_PM_ADM_10", "PM: Errore durante l'eliminazione di dati limite");
