<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/11 18:11:20
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/
define("LAN_PLUGIN_PM_NAME", "Messaggistica Privata");
define("LAN_PLUGIN_PM_DESCRIPTION", "Questo plugin è un completo sistema di messaggistica privata.");
define("LAN_PLUGIN_PM_URL_DEFAULT_LABEL", "Impostazione predefinita");
define("LAN_PLUGIN_PM_URL_DEFAULT_DESCR", "Impostazione predefinita");
define("LAN_PLUGIN_PM_INBOX", "Posta in arrivo");
define("LAN_PLUGIN_PM_OUTBOX", "Posta in uscita");
define("LAN_PLUGIN_PM_NEW", "Invia Nuovo Messaggio");
define("LAN_PLUGIN_PM_TO", "A");
define("LAN_PLUGIN_PM_FROM", "Da");
define("LAN_PLUGIN_PM_SUB", "Oggetto");
define("LAN_PLUGIN_PM_MESS", "Messaggio");
define("LAN_PLUGIN_PM_READ", "Letto");
define("LAN_PLUGIN_PM_DEL", "Cancella Messaggio Privato");
define("LAN_PLUGIN_PM_ATTACHMENT", "Allegato");
define("LAN_PLUGIN_PM_SIZE", "Volume");


?>