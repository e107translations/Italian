<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/11/07 23:27:02
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_TAGCLOUD_NAME", "Tag Cloud");
define("LAN_PLUGIN_TAGCLOUD_DESCRIPTION", "Un semplice blocco Tagcloud per il tuo sito web e107");


?>