<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("CM_L1", "Nessun commento ancora.");
define("CM_L2", "");
define("CM_L3", "Didascalia");
define("CM_L4", "Numero di commenti da visualizzare?");
define("CM_L5", "Numero di caratteri da visualizzare?");
define("CM_L6", "Postfix per commenti troppo lunghi?");
define("CM_L7", "Mostra titolo originale notizie nel menu?");
define("CM_L8", "Nuova configurazione del Menu Commenti");
define("CM_L11", "il");
define("CM_L12", "Re:");
define("CM_L13", "Inviato da");
