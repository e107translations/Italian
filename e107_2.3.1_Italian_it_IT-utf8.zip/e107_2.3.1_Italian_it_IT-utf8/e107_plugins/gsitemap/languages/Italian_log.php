<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_AL_GSMAP_01", "Importare i sitelink");
define("LAN_AL_GSMAP_02", "Mappa del sito link cancellato");
define("LAN_AL_GSMAP_03", "Mappa del sito link aggiunto");
define("LAN_AL_GSMAP_04", "Mappa del sito link aggiornato");
