<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/11/07 23:26:01
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/
define("POLLAN_3", "Domanda del sondaggio");
define("POLLAN_4", "Opzioni di sondaggio");
define("POLLAN_12", "Visualizza risultati");
define("POLLAN_13", "dopo il voto");
define("POLLAN_14", "facendo clic su Visualizza risultati link - commenti devono essere accesi per poter utilizzare questa opzione");
define("POLLAN_15", "Permettono di votare in questo sondaggio");
define("POLLAN_16", "Metodo di archiviazione di voto");
define("POLLAN_17", "biscotto");
define("POLLAN_19", "ID utente (solo i membri possono votare)");
define("POLLAN_28", "Sondaggi precedenti");
define("POLLAN_31", "Voti");
define("POLLAN_40", "Clicca qui per vedere i risultati");
define("POLLAN_41", "Questo sondaggio è limitato ai soli membri");
define("POLLAN_42", "Questo sondaggio è limitato ai soli amministratori");
define("POLLAN_43", "Non si dispone delle autorizzazioni necessarie per votare in questo sondaggio");
define("POLLAN_50", "Attivo da [x] a [y]");
define("LAN_FORUM_3029", "Se non si desidera aggiungere un sondaggio al tuo argomento, lasciare i campi vuoti.");


?>