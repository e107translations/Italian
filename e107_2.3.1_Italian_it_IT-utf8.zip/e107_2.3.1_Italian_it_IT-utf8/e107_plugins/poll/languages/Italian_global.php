<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_PLUGIN_POLL_NAME", "Sondaggio");
define("LAN_PLUGIN_POLL_DESCRIPTION", "Il plugin di sondaggio consente di definire sondaggi in entrambi un post dal menu o forum.");
