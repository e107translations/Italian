<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/11 00:36:15
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/
define("TMCEALAN_1", "Incollare come testo di default");
define("TMCEALAN_2", "Controllo ortografico dal Browser");
define("TMCEALAN_3", "Abilitalo se desideri utilizzare il correttore interno al browser");
define("TMCEALAN_4", "Visualizza Blocchi");
define("TMCEALAN_5", "abilita la visualizzazione dei blocchi HTML durante le modifiche");
define("TMCEALAN_6", "Classe CSS per evidenziare il Codice");
define("TMCEALAN_7", "Usa lo stile frontend");
define("TMCEALAN_8", "Quando abilitato, l'editor utilizzerà lo stile del tema del frontend. (se supportato) ");
