<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("BLOGCAL_L1", "Notizie per mese");
define("BLOGCAL_L2", "Archivio");
define("BLOGCAL_1", "Articoli di notizie");
define("BLOGCAL_CONF1", "Mesi/riga");
define("BLOGCAL_CONF2", "Cellpadding");
define("BLOGCAL_CONF4", "BlogCal Menu configurazione");
define("BLOGCAL_ARCHIV1", "Selezionare Archivio");
