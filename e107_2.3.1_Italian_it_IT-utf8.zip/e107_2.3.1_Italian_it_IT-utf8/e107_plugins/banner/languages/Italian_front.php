<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/10 23:44:38
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("BANNERLAN_19", "Inserisci il tuo client login e password per continuare");
define("BANNERLAN_20", "Siamo spiacenti, Impossibile trovare quei dettagli nel database. Per informazioni dettagliate, si prega di contattare l'amministratore del sito.");
define("BANNERLAN_21", "Statistiche di banner");
define("BANNERLAN_22", "Client");
define("BANNERLAN_23", "ID di banner");
define("BANNERLAN_24", "Clickthrough");
define("BANNERLAN_25", "Fare clic su %");
define("BANNERLAN_26", "Impressioni");
define("BANNERLAN_27", "Impressioni acquistate");
define("BANNERLAN_28", "Impressioni di sinistra");
define("BANNERLAN_30", "Illimitato");
define("BANNERLAN_31", "Non applicabile");
define("BANNERLAN_35", "Indirizzi IP di clickthrough");
define("BANNERLAN_39", "Non è stata assegnata nessuna immagine a questo banner.");


?>