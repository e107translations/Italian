<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_AL_LINKWD_00", "Messaggio di Linkword");
define("LAN_AL_LINKWD_01", "Linkword aggiunto");
define("LAN_AL_LINKWD_02", "Linkword modificato");
define("LAN_AL_LINKWD_03", "Linkword cancellato");
define("LAN_AL_LINKWD_04", "Linkword opzioni aggiornate");
define("LAN_AL_LINKWD_05", "Aggiornamento versione LinkWords");
