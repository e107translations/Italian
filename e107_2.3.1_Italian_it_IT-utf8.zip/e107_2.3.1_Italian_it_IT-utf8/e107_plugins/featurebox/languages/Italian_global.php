<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2021/03/14 01:36:13
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_FEATUREBOX_NAME", "Featurebox");
define("LAN_PLUGIN_FEATUREBOX_DESCRIPTION", "Viene visualizzata un'area animata nella parte superiore la pagina tra-notizie e altri contenuti che si desidera dispongono.");
define("LAN_PLUGIN_FEATUREBOX_BATCH", "Creare Featurebox elemento");
define("LAN_PLUGIN_FEATUREBOX_RSSFEED", "Questo è il feed RSS per le voci Featurebox. ");
