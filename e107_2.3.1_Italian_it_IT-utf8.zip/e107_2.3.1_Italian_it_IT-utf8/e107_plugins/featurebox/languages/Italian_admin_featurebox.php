<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/11/07 23:21:05
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/
define("FBLAN_08", "Testo del messaggio");
define("FBLAN_12", "Modalità");
define("FBLAN_13", "Rotazione casuale dei messaggi");
define("FBLAN_14", "Visualizza questo messaggio solo");
define("FBLAN_22", "Tipo di rendering");
define("FBLAN_23", "Nel box ");
define("FBLAN_24", "Piano");
define("FBLAN_25", "non ci sono elementi featurebox assegnati al template [x]");
define("FBLAN_26", "Immagine/Video");
define("FBLAN_27", "Link Immagine");
define("FBLAN_28", "Categoria Menù Featurebox");
define("FBLAN_29", "Categoria da utilizzare per il menù featurebox");
define("FBLAN_30", "Categoria template");
define("FBLAN_31", "Casuali");
define("FBLAN_32", "Parametri (opzionale)");
define("FBLAN_33", "Parametri Javascript opzionali (formato soggetto a modifica)");
define("FBLAN_34", "Non assegnati");
define("FBLAN_35", "Carosello");
define("FBLAN_36", "Schede");
