<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("FBLAN_08", "Testo del messaggio");
define("FBLAN_12", "Modalità");
define("FBLAN_13", "Ruotano in modo casuale i messaggi");
define("FBLAN_14", "Visualizza questo messaggio solo");
define("FBLAN_22", "Tipo di rendering");
define("FBLAN_23", "Nella casella tema");
define("FBLAN_24", "Pianura");
