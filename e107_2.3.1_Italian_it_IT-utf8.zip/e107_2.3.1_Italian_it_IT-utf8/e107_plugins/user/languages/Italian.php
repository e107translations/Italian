<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/11 00:32:26
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/
define("UTHEME_MENU_L1", "Setta");
define("UTHEME_MENU_L2", "Seleziona la lingua");
define("UTHEME_MENU_L3", "Tabelle");
define("LAN_UMENU_THEME_1", "Imposta il Tema");
define("LAN_UMENU_THEME_2", "Seleziona il Tema");
define("LAN_UMENU_THEME_3", "utenti:");
define("LAN_UMENU_THEME_4", "Abilita i template che vuoi mettere a disposizione degli utenti.");
define("LAN_UMENU_THEME_5", "Aggiorna");
define("LAN_UMENU_THEME_6", "Temi disponibili agli utenti");
define("LAN_UMENU_THEME_7", "Classe di appartenenza per selezionare i temi");
define("LAN_UMENU_THEME_8", "Temi Autorizzati");
define("LAN_UMENU_THEME_9", "Classe di appartenenza per selezionare i temi:");


?>