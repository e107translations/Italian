<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("POLL_ADLAN03", "Configurare sondaggi");
define("POLL_ADLAN04", "Il sondaggio plugin è stato installato correttamente. Per aggiungere sondaggi, fare clic sull'icona di sondaggi nella sezione plugin del vostro admin prima pagina e ricordarsi di attivare la voce di menu dalla tua pagina di menu.");
define("POLL_ADLAN05", "Sondaggio principale:");
define("POLL_ADLAN06", "Thread del forum:");
define("POLL_ADLAN07", "Tipo");
define("POLLAN_MENU_CAPTION", "Sondaggio");
define("POLLAN_7", "Nessun sondaggio ancora.");
define("LAN_AL_POLL_01", "Sondaggio eliminato");
define("LAN_AL_POLL_02", "Sondaggio aggiornato");
define("LAN_AL_POLL_03", "Sondaggio aggiunto");
define("LAN_AL_POLL_04", "");
define("LAN_AL_POLL_05", "");
