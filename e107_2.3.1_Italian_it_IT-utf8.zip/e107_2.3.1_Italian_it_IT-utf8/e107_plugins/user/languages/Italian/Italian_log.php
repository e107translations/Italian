<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_AL_AUTH_01", "Alt auth impostazioni modificate");
define("LAN_AL_AUTH_02", "Auth Alt esteso classi utente modificate");
define("LAN_AL_AUTH_03", "Ha cambiate le impostazioni del metodo di Alt auth");
