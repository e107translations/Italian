<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("E107DB_LAN_1", "Database di formato di e107");
define("E107DB_LAN_9", "Metodo di password:");
define("E107DB_LAN_10", "Configurare E107 db auth");
define("E107DB_LAN_11", "Selezionare la casella contro qualsiasi campo che si desidera essere trasferiti al database locale:");
define("IMPORTDB_LAN_7", "MD5 (E107 originale)");
define("IMPORTDB_LAN_8", "E107 salato (opzione 2.0)");
define("LAN_AUTHENTICATE_HELP", "Questo metodo di autenticazione deve essere utilizzato con un secondo database di E107, che può utilizzare un formato di password diversa per questo sistema. La password originale è leggere dal database locale e convalidata rispetto al formato di archiviazione del sistema originale. Se si verifica, sua convertito nel formato corrente di E107-compatibile e memorizzati nel database.");
