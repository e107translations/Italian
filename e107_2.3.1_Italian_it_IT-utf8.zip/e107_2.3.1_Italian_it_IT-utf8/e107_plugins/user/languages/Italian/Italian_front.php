<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_dl_1", "(Limitato)");
define("LAN_dl_4", "File disponibili:");
define("LAN_dl_5", "Dimensione totale dei file:");
define("LAN_dl_6", "I file scaricati:");
define("LAN_dl_8", "Ottieni");
define("LAN_dl_9", "Tornare alla lista delle categorie");
define("LAN_dl_13", "Non valutato");
define("LAN_dl_14", "Questo download di tasso");
define("LAN_dl_16", "Download (s) da");
define("LAN_dl_29", "Di DL");
define("LAN_dl_30", "Autore e-mail");
define("LAN_dl_31", "Sito Web autore");
define("LAN_dl_36", "Nuovi download");
define("LAN_dl_40", "Cliccare qui per gli screenshot");
define("LAN_dl_43", "Voto");
define("LAN_dl_44", "voti");
define("LAN_dl_45", "Rapporto rotto-Scarica");
define("LAN_dl_46", "Clicca qui per scaricare");
define("LAN_dl_47", "Post è stato segnalato");
define("LAN_dl_48", "Il download è stato segnalato all'amministratore.<br>Grazie.");
define("LAN_dl_49", "Clicca qui per tornare a scaricare");
define("LAN_dl_50", "Download interrotto segnalati");
define("LAN_dl_51", "Il download di Reporting:");
define("LAN_dl_53", "Fare clic per visualizzare il download");
define("LAN_dl_54", "Amministratore verrà resi consapevole di questo download, si prega di lasciare un messaggio se lo ritieni necessario.");
define("LAN_dl_55", "Non utilizzare questo modulo per contattare l'amministratore per qualsiasi altro motivo.");
define("LAN_dl_57", "segnalato da");
define("LAN_dl_58", "Il seguente download è stato segnalato come rotto dal sito");
define("LAN_dl_59", "Segnalato da:");
define("LAN_dl_60", "Relazione rotto-Scarica");
define("LAN_dl_62", "È stato impedito di scaricare questo file; è stato superato la quota di download");
define("LAN_dl_63", "Non si dispone delle autorizzazioni corrette per scaricare questo file.");
define("LAN_dl_66", "Selezionare download mirror");
define("LAN_dl_67", "Selezionare specchio...");
define("LAN_dl_68", "Specchio Host");
define("LAN_dl_72", "Richiesta di file:");
define("LAN_dl_73", "Download da questo mirror:");
define("LAN_dl_74", "Download totali da questo mirror:");
define("LAN_dl_75", "Nessuna immagine disponibile");
define("LAN_dl_77", "Download");
define("LAN_dl_78", "Che il download è stato disattivato o interrotto. Si prega di controllare [area Download] per una versione più recente.");
