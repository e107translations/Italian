<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_RADIUS_01", "Indirizzo del server");
define("LAN_RADIUS_02", "Segreto condiviso");
define("LAN_RADIUS_03", "Utente di server");
define("LAN_RADIUS_04", "Password del server");
define("LAN_RADIUS_06", "Configurare RADIUS auth");
define("LAN_RADIUS_11", "Attenzione: Sembra che il modulo del raggio non è attualmente disponibile; impostando il metodo auth RADIUS probabilmente non funzionerà!");
define("LAN_AUTHENTICATE_HELP", "Questo metodo di autenticazione viene utilizzato con un server RADIUS esterno. Si requres che l'estensione del raggio di PHP è abilitato.<br>Si noti che il server RADIUS può solo consentire l'accesso da un specifico intervallo di indirizzi IP");
