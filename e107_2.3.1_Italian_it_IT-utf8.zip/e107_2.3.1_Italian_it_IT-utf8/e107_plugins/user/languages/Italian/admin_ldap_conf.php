<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LDAPLAN_1", "Indirizzo del server");
define("LDAPLAN_2", "Base DN o dominio<br>LDAP - immettere BaseDN<br>Annuncio - immettere il nome fqdn es ad.mydomain.co.uk");
define("LDAPLAN_3", "Utente di esplorazione LDAP<br>Contesto completo dell'utente che è in grado di cercare la directory.");
define("LDAPLAN_4", "Password di esplorazione LDAP<br>Password per l'utente di esplorazione LDAP.");
define("LDAPLAN_5", "Versione LDAP");
define("LDAPLAN_6", "Configurare LDAP auth");
define("LDAPLAN_7", "filtro di ricerca di eDirectory:");
define("LDAPLAN_8", "Verrà utilizzato per assicurarsi che il nome utente sia l'albero corretto,<br>ad esempio '(objectclass=inetOrgPerson)'");
define("LDAPLAN_9", "Filtro di ricerca corrente sarà:");
define("LDAPLAN_10", "Impostazioni aggiornate");
define("LDAPLAN_11", "Attenzione: Sembra che il modulo ldap non è attualmente disponibile; il metodo di autenticazione è impostato come LDAP probabilmente non funzionerà!");
define("LDAPLAN_12", "Tipo di server");
define("LDAPLAN_13", "Impostazioni di aggiornamento");
define("LDAPLAN_14", "Unità organizzativa per annuncio (ad esempio ou = itdept)");
define("LAN_AUTHENTICATE_HELP", "Questo metodo può essere utilizzato per autenticare contro la maggior parte dei server LDAP, tra cui eDirectory di Novell\ e Active Directory di Microsoft. Richiede che sia caricata estensione LDAP di php. Consultare il wiki per maggiori informazioni.");
