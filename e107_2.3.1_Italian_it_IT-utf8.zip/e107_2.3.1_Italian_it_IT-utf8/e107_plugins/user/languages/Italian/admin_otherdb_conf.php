<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("OTHERDB_LAN_1", "Tipo di database:");
define("OTHERDB_LAN_2", "Server:");
define("OTHERDB_LAN_3", "Nome utente:");
define("OTHERDB_LAN_4", "Password:");
define("OTHERDB_LAN_5", "Database");
define("OTHERDB_LAN_6", "Tabella");
define("OTHERDB_LAN_7", "Campo nome utente:");
define("OTHERDB_LAN_8", "Campo password:");
define("OTHERDB_LAN_9", "Metodo di password:");
define("OTHERDB_LAN_10", "Configurare otherdb auth");
define("OTHERDB_LAN_12", "Giacimento del sale password:");
define("OTHERDB_LAN_13", "(Lasciare vuoto se non utilizzato)");
define("OTHERDB_LAN_14", "Campo di indirizzo di posta elettronica:");
define("OTHERDB_LAN_15", "MySQL - database generico");
define("LAN_AUTHENTICATE_HELP", "Questo metodo di autenticazione viene utilizzato per convalidare in base a un database non-E107. La password deve essere archiviata in uno dei formati supportati.");
