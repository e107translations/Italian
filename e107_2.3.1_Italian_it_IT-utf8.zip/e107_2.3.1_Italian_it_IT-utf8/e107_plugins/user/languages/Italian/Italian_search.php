<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("FOR_SCH_LAN_2", "Seleziona forum");
define("FOR_SCH_LAN_4", "Intero post");
define("FOR_SCH_LAN_5", "Come parte del thread");
