<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_FORUM_MENU_001", "Inviato da");
define("LAN_FORUM_MENU_002", "Ancora nessun post");
define("LAN_FORUM_MENU_003", "Nuova configurazione del menu messaggi del Forum salvata");
define("LAN_FORUM_MENU_004", "Didascalia");
define("LAN_FORUM_MENU_005", "Numero di messaggi da visualizzare?");
define("LAN_FORUM_MENU_006", "Numero di caratteri da visualizzare?");
define("LAN_FORUM_MENU_007", "Postfix per post troppo lunghi?");
define("LAN_FORUM_MENU_008", "Mostra argomenti originale nel menu?");
define("LAN_FORUM_MENU_009", "Aggiornare le impostazioni del menu");
define("LAN_FORUM_MENU_0010", "Nuovo Forum Post Menu configurazione");
define("LAN_FORUM_MENU_0012", "Età massima di post visualizzati");
define("LAN_FORUM_MENU_0013", "Utilizzare zero su un sito tranquillo; impostazione di un valore in giorni ridurrà il tempo di database su un sito occupato");
