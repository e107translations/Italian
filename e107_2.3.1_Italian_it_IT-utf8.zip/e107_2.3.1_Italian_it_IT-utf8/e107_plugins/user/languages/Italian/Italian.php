<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/09 01:53:29
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/
define("CHATBOX_L1", "Incapace di accettare il posto come tale nome utente è registrato - se è il tuo nome utente effettua il login per postare.");
define("CHATBOX_L3", "Devi essere autenticato per pubblicare commenti su questo sito web. -
per registrarti o accedere premi [Qui].");
define("CHATBOX_L3b", "Se non sei registrato premi [QUI] per  procedere");
define("CHATBOX_L4", "Nuovo messaggio di posta");
define("CHATBOX_L5", "Resetta");
define("CHATBOX_L6", "[bloccato da admin]");
define("CHATBOX_L7", "Sbloccare");
define("CHATBOX_L8", "Info");
define("CHATBOX_L9", "Blocco");
define("CHATBOX_L11", "Messaggi non ancora.");
define("CHATBOX_L12", "Visualizza tutti i post");
define("CHATBOX_L13", "chatbox moderata");
define("CHATBOX_L14", "EMote");
define("CHATBOX_L15", "Post troppo lunghi o vuoto post presentato");
define("CHATBOX_L17", "Post duplicato");
define("CHATBOX_L18", "Messaggi di ChatBox moderati");
define("CHATBOX_L19", "Puoi solo pubblicare una volta ogni '. (FLOODPROTECT? FLOODTIMEOUT: 'n/a'). 'secondi");
define("CHATBOX_L20", "Chatbox (tutti i messaggi)");
define("CHATBOX_L22", "il");
define("CHATBOX_L24", "Non si dispone delle autorizzazioni corrette per visualizzare questa pagina.");
define("CHATBOX_L25", "[questo post è stato bloccato da admin]");
define("LAN_CHATBOX_100", "Digita qui il tuo messaggio.");


?>