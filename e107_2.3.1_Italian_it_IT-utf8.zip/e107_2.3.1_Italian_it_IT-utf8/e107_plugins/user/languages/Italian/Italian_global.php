<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_PLUGIN__BLANK_NAME", "Plugin in bianco");
define("LAN_PLUGIN__BLANK_DIZ", "Un Plugin vuoto per aiutarti a iniziare lo sviluppo di plugin. Maggiori dettagli possono essere aggiunti qui.");
define("LAN_PLUGIN__BLANK_LINK", "Collegamento vuoto");
