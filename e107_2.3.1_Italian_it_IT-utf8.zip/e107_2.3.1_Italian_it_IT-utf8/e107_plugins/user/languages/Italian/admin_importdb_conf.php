<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("IMPORTDB_LAN_9", "Metodo di password:");
define("IMPORTDB_LAN_10", "Configurare il tipo di password di database importato");
define("IMPORTDB_LAN_11", "Questa opzione deve essere utilizzato quando aver importato qualche altro sistema basato sull'utente in E107. 
							Esso consente di accettare le password codificate nel formato non standard selezionato. 
							Password di ogni utente di s viene convertito in formato E107 quando accedono.");
define("LAN_AUTHENTICATE_HELP", "Questo metodo di autenticazione deve essere usato <i>solo</i> quando aver importato un database utente in E107, e la password è in un formato incompatibile. La password originale è leggere dal database locale e convalidata rispetto al formato di archiviazione del sistema originale. Se si verifica, sua convertito nel formato corrente di E107-compatibile e memorizzati nel database. Dopo un po' è solitamente possibile disattivare il plugin di alt-auth, poiché utenti attivi avrà tutte le password memorizzate in un formato compatibile.");
