<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_FORUM_NT_7", "Forum - Thread creato da nuovo utente");
define("LAN_FORUM_NT_8", "Forum - Discussione eliminata");
define("LAN_FORUM_NT_9", "Forum - split Thread");
define("LAN_FORUM_NT_10", "Forum - Post cancellato");
define("LAN_FORUM_NT_11", "Forum - Post segnalati");
define("LAN_FORUM_NT_NEWTOPIC", "Creato un nuovo argomento");
define("LAN_FORUM_NT_NEWTOPIC_PROB", "Nuovo argomento creato da prova membro");
define("LAN_FORUM_NT_TOPIC_DELETED", "Argomento eliminato");
define("LAN_FORUM_NT_TOPIC_SPLIT", "Argomento di Spalato");
define("LAN_FORUM_NT_POST_DELETED", "Post eliminato");
define("LAN_FORUM_NT_POST_REPORTED", "Riportato il post");
