<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_ALT_1", "Tipo di autorizzazione primario");
define("LAN_ALT_2", "Impostazioni di aggiornamento");
define("LAN_ALT_3", "Scegliere il tipo di autorizzazione alternativo");
define("LAN_ALT_4", "Configurare i parametri per");
define("LAN_ALT_5", "Configurare i parametri di autorizzazione");
define("LAN_ALT_6", "Connessione non riuscita azione");
define("LAN_ALT_7", "In caso di connessione per il tipo di autorizzazione primaria (e non il locale e107 DB), come deve essere gestito?");
define("LAN_ALT_8", "Tipo di autorizzazione secondaria");
define("LAN_ALT_9", "Viene utilizzato se il metodo di autorizzazione primario non riesce a trovare l'utente");
define("LAN_ALT_10", "Campo nome di accesso utente");
define("LAN_ALT_11", "Campo password utente");
define("LAN_ALT_12", "Campo email utente");
define("LAN_ALT_13", "Nascondere email? campo");
define("LAN_ALT_14", "Campo di nome utente visualizzato");
define("LAN_ALT_15", "Campo di vero nome utente");
define("LAN_ALT_16", "Campo Custom titolo utente");
define("LAN_ALT_17", "Campo firma");
define("LAN_ALT_18", "Campo di avatar");
define("LAN_ALT_19", "Foto field");
define("LAN_ALT_20", "Aggiungere il campo Data");
define("LAN_ALT_21", "Campo di stato di divieto");
define("LAN_ALT_22", "Campo di appartenenza di classe");
define("LAN_ALT_24", "Giacimento del sale password");
define("LAN_ALT_25", "(a volte combinati con password per una maggiore sicurezza)");
define("LAN_ALT_26", "Tipo di database:");
define("LAN_ALT_27", "Per trasferire un valore di campo nel database locale, è necessario specificare il nome del campo nella casella corrispondente qui sotto. (Nome utente e la password vengono sempre trasferiti)<br>Lasciare il campo vuoto per esso non deve essere trasferito a tutte le");
define("LAN_ALT_29", "Metodi auth");
define("LAN_ALT_30", "Configurare");
define("LAN_ALT_31", "Configurazione principale");
define("LAN_ALT_32", "Server:");
define("LAN_ALT_33", "Nome utente:");
define("LAN_ALT_34", "Password:");
define("LAN_ALT_35", "Database:");
define("LAN_ALT_36", "Tabella:");
define("LAN_ALT_37", "Campo nome utente:");
define("LAN_ALT_38", "Campo password:");
define("LAN_ALT_39", "Prefisso di tabella:");
define("LAN_ALT_40", "Accesso al database di test");
define("LAN_ALT_41", "(con sopra le credenziali)");
define("LAN_ALT_42", "Se un nome utente e la password vengono immessi, tale utente verrà convalidato anche");
define("LAN_ALT_43", "Connessione al database di successo");
define("LAN_ALT_44", "Connessione al database non riuscita");
define("LAN_ALT_45", "Nome utente ricerca successo");
define("LAN_ALT_46", "Ricerca di uername non riuscita");
define("LAN_ALT_47", "Prova");
define("LAN_ALT_48", "Precedente convalida");
define("LAN_ALT_49", "Username =");
define("LAN_ALT_50", "Password =");
define("LAN_ALT_51", "(vuoto)");
define("LAN_ALT_52", "Autenticazione non riuscita-");
define("LAN_ALT_53", "causa sconosciuta");
define("LAN_ALT_54", "non poteva connettersi al DB / fornitore di servizi");
define("LAN_ALT_55", "utente non valido");
define("LAN_ALT_56", "password non valida");
define("LAN_ALT_57", "Metodo non disponibile");
define("LAN_ALT_58", "Autenticazione riuscita");
define("LAN_ALT_59", "Estratto parametri:");
define("LAN_ALT_60", "Campi utente estesa");
define("LAN_ALT_61", "Consentire");
define("LAN_ALT_62", "Nome del campo");
define("LAN_ALT_63", "Descrizione");
define("LAN_ALT_64", "Tipo");
define("LAN_ALT_65", "Autenticazione alternativo");
define("LAN_ALT_66", "Questo plugin permette metodi di autenticazione alternativo.");
define("LAN_ALT_67", "Configurare Alt auth");
define("LAN_ALT_68", "Servizio auth ALT è ora impostato.  Ora sarà necessario configurare il tuo metodo preferito.");
define("LAN_ALT_69", "");
define("LAN_ALT_70", "Nessuno");
define("LAN_ALT_71", "VERO/FALSO");
define("LAN_ALT_72", "Lettere maiuscole");
define("LAN_ALT_73", "Lettere minuscole");
define("LAN_ALT_74", "Primo superiore");
define("LAN_ALT_75", "Parole superiore");
define("LAN_ALT_76", "Restrizione di classe utente (valore numerico - zero o vuoto per tutti)");
define("LAN_ALT_77", "Accesso sono consentiti solo agli utenti in questa classe (sul database di cui sopra)");
define("LAN_ALT_78", "Password non riuscita azione");
define("LAN_ALT_79", "Se l'utente esiste in DB primario, ma immette una password errata, come dovrebbe che essere gestito?");
define("IMPORTDB_LAN_2", "Testo normale");
define("IMPORTDB_LAN_3", "Joomla salato");
define("IMPORTDB_LAN_4", "Mambo salato");
define("IMPORTDB_LAN_5", "SMF (SHA1)");
define("IMPORTDB_LAN_6", "SHA1 generico");
define("IMPORTDB_LAN_7", "MD5 (E107 originale)");
define("IMPORTDB_LAN_8", "E107 salato (opzione 2.0)");
define("IMPORTDB_LAN_12", "PHPBB2/PHPBB3 salato");
define("IMPORTDB_LAN_13", "WordPress salato");
define("IMPORTDB_LAN_14", "Magento salato");
define("LAN_ALT_FALLBACK", "Autorizzazione secondaria all'uso");
define("LAN_ALT_FAIL", "Accesso non riuscito");
define("LAN_ALT_UPDATESET", "Impostazioni di aggiornamento");
define("LAN_ALT_UPDATED", "Impostazioni aggiornate");
define("LAN_ALT_AUTH_HELP", "Queste sono le impostazioni comuni a tutti i metodi di autenticazione e determinare le azioni da intraprendere<br><br>La selezione del campo utente estesa determina quale <i>può</i> essere aggiunto/aggiornato quando un utente si connette - ulteriore configurazione è necessaria per il metodo di autenticazione specifico.");
define("LAN_ALT_VALIDATE_HELP", "È possibile controllare le impostazioni utilizzando il \'Test Database Access\' sezione per provare e convalidare un utente - questo utilizza esattamente lo stesso processo come quando un utente tenta di accedere e conferma se le impostazioni sono corrette.<br>Se è stato configurato alcuni parametri per essere copiate nella tabella utente il login di successo, questi sono anche elencati.");
define("LAN_ALT_COPY_HELP", "È possibile selezionare campi da copiare dal database remoto nel database utente immettendo i nomi appropriati.<br><br>");
define("LAN_ALT_CONVERSION_HELP", "Per alcuni campi, la casella a discesa a destra della casella di immissione di campo consente di selezionare una conversione che può essere applicata sul valore letto dal database remoto; Se \'none\' è selezionata, il valore viene copiato come ricevuto. Le conversioni sono:<br>
	<b>Vero/falso</b> - le parole \'TRUE\' e \'FALSE\' (e la loro bassa/misto causa equivalenti) vengono convertiti in valori booleani 1 e zero.<br>
	<b>Lettere maiuscole</b> - tutte le lettere vengono convertite in lettere maiuscole<br>
	<b>Lettere minuscole</b> - tutte le lettere vengono convertite in lettere minuscole<br>
	<b>Superiore prima</b> -il primo carattere viene convertito in lettere maiuscole<br>
	<b>Parole di superiore</b> - la prima lettera di ogni parola viene convertita in lettere maiuscole<br>
	<br>
	<br>");
