<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("NFLAN_29", "Newsfeed disponibili");
define("NFLAN_31", "Torna alla lista di newsfeed");
define("NFLAN_33", "Data di pubblicazione:");
define("NFLAN_34", "non noto");
define("NFLAN_38", "Notizie");
define("NFLAN_39", "Dettagli");
define("NFLAN_48", "Impossibile salvare i dati non elaborati nel database.");
