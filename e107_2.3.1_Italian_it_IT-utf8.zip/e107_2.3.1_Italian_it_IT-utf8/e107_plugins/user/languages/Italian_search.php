<?php

define('CM_SCH_LAN_1', 'Calendario');  //FIXME Use English_global.php

?>
