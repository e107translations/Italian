<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("TRACKBACK_L7", "Attivare il trackback");
define("TRACKBACK_L8", "Testo di Trackback URL");
define("TRACKBACK_L10", "Impostazioni di trackback");
define("TRACKBACK_L11", "Indirizzo di trackback per questo post:");
define("TRACKBACK_L12", "Nessun trackbacks per questo articolo");
define("TRACKBACK_L13", "Trackbacks moderata");
define("TRACKBACK_L16", "Trackback");
