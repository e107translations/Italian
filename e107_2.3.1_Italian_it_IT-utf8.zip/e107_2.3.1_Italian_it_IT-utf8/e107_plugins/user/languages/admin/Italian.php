<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("CLOCK_AD_L2", "Didascalia");
define("CLOCK_AD_L4", "Orologio Menu Config");
define("CLOCK_AD_L5", "AM/PM");
define("CLOCK_AD_L6", "Se selezionata, verrà visualizzato il tempo con gli Stati Uniti formato (0-12 AM/PM). Unchecked che visualizzerà un formato 'militare' formato 0-24");
define("CLOCK_AD_L7", "Prefisso di data");
define("CLOCK_AD_L8", "Se il tuo linguaggio richiede una breve parola prima della data (ad esempio ' le' per il francese) o 'den' per il tedesco..., utilizzare questo campo. Se non richiesto, lasciare vuoto.");
define("CLOCK_AD_L9", "Suffisso 1");
define("CLOCK_AD_L10", "Suffisso 2");
define("CLOCK_AD_L11", "Suffisso 3");
define("CLOCK_AD_L12", "Suffisso di 4 e più");
define("CLOCK_AD_L13", "Se il tuo linguaggio richiede per visualizzare un suffisso solo dopo i numeri per data, riempire questi campi con suffisso solo (esempio: 'st' 1, 'nd' per 2, 'rd' per 3 e 'th' per 4 e più - per gli utenti inglesi). Se non è necessario lasciare vuoto.");
