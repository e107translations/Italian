<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/11 00:29:45
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_USER_NAME", "Utente");
define("LAN_PLUGIN_USER_DESC", "Tema Utente e Menù di Lingua");


?>