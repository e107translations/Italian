<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/11 00:16:40
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("LIST_MENU_1", "aggiunte recenti");
define("LIST_MENU_2", "da");
define("LIST_MENU_3", "il");
define("LIST_MENU_4", "in");
define("LIST_MENU_5", "giorni");
define("LIST_MENU_6", "Mostra contenuto per quanti giorni?");
define("LIST_MENU_7", "");
define("LIST_MENU_8", "");
define("LIST_MENU_9", "");
define("LIST_MENU_10", "");
define("LIST_MENU_11", "");
define("LIST_MENU_12", "");
define("LIST_MENU_13", "");
define("LIST_MENU_14", "");
define("LIST_MENU_15", "");
define("LIST_MENU_16", "");
define("LIST_MENU_17", "");
define("LIST_MENU_18", "");
define("LIST_MENU_19", "");
define("LIST_NEWS_1", "Notizie");
define("LIST_NEWS_2", "Nessun elemento di novità");
define("LIST_COMMENT_1", "Commenti");
define("LIST_COMMENT_2", "non ci sono commenti");
define("LIST_COMMENT_3", "Notizie");
define("LIST_COMMENT_4", "Domande frequenti");
define("LIST_COMMENT_5", "sondaggio");
define("LIST_COMMENT_6", "documenti");
define("LIST_COMMENT_7", "bugtrack");
define("LIST_COMMENT_8", "contenuto");
define("LIST_COMMENT_9", "");
define("LIST_COMMENT_10", "idee");
define("LIST_MEMBER_1", "membri");
define("LIST_MEMBER_2", "non membri");
define("LIST_CONTENT_1", "contenuto");
define("LIST_CONTENT_2", "Nessun contenuto in");
define("LIST_CONTENT_3", "Nessuna categoria di contenuto valida");
define("LIST_CHATBOX_1", "ChatBox");
define("LIST_CHATBOX_2", "nessun post chatbox");
define("LIST_CALENDAR_1", "calendario");
define("LIST_CALENDAR_2", "Nessun calendario eventi");
define("LIST_LINKS_1", "collegamenti");
define("LIST_LINKS_2", "Nessun link");
define("LIST_FORUM_1", "Cose da fare");
define("LIST_FORUM_2", "Nessun messaggi nel forum");
define("LIST_FORUM_3", "Visualizzazioni:");
define("LIST_FORUM_4", "risposte:");
define("LIST_FORUM_5", "lastpost:");
define("LIST_FORUM_6", "formica");
define("LIST_LAN_1", "Nessun elemento in");
define("LIST_DOWNLOAD_1", "Downloads");
define("LIST_DOWNLOAD_2", "Nessun Downloads");


?>