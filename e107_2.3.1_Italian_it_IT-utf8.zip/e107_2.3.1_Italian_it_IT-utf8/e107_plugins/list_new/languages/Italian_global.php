<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2018/09/13 13:56:14
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_LIST_NEW_NAME", "Lista dei Nuovi Articoli");
define("LAN_PLUGIN_LIST_NEW_DESCRIPTION", "Questo plugin consente di visualizzare un elenco e / o un menu di aggiunte recenti in tutte le categorie e107. È possibile visualizzare l'elenco con i dati dall'ultima visita o visualizzare un elenco di aggiunte più recenti.");
