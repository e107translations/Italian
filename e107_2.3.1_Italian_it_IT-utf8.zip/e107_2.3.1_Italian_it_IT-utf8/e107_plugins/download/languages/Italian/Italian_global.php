<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2021/03/14 01:35:50
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_DOWNLOAD_NAME", "Download");
define("LAN_PLUGIN_DOWNLOAD_DIZ", "Questo plugin è un completo sistema di download di File");
define("LAN_DL_NT_01", "Download incompleto segnalato");
define("LAN_DL_NT_02", "Il download seguente è stato segnalato come guasto ho incompleto:");
define("LAN_DL_NT_03", "È stato segnalato da [x] con il seguente commento:");
define("LAN_DL_NT_04", "Fare clic [qui] per visualizzare i rapporti sui download guasti o incompleti. ");
define("LAN_DL_LATEST_01", "Download guasti o incompleti segnalati ");
