<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_AL_DOWNL_01", "Download - Scarica opzioni modificate");
define("LAN_AL_DOWNL_02", "Download - upload opzioni modificate");
define("LAN_AL_DOWNL_03", "Download - aggiunto limite");
define("LAN_AL_DOWNL_04", "Downloads - accedere 04");
define("LAN_AL_DOWNL_05", "Downloads - accedere 05");
define("LAN_AL_DOWNL_06", "Downloads - accedere 06");
define("LAN_AL_DOWNL_07", "Downloads - registro 07");
define("LAN_AL_DOWNL_08", "Downloads - accedere 08");
define("LAN_AL_DOWNL_09", "Downloads - accedere 09");
define("LAN_AL_DOWNL_10", "Downloads - limite aggiornato");
define("LAN_AL_DOWNL_11", "Download - limite rimosso");
