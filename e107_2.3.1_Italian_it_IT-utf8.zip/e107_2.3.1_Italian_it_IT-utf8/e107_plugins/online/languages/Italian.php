<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/11 00:24:55
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("LAN_LASTSEEN_1", "Ultimo visto Menu");
define("LAN_ONLINE_TRACKING_MESSAGE", "Il tracciamento degli utenti online è attualmente disabilitato, si prega di abilitare [qui]");
define("LAN_ONLINE_1", "Ospiti:");
define("LAN_ONLINE_2", "Membri:");
define("LAN_ONLINE_3", "In questa pagina:");
define("LAN_ONLINE_4", "Online");
define("LAN_ONLINE_5", "");
define("LAN_ONLINE_6", "Ultimo iscritto:");
define("LAN_ONLINE_7", "visualizzazione");
define("LAN_ONLINE_8", "Record presenze:");
define("LAN_ONLINE_9", "il");
define("LAN_ONLINE_10", "Menu on-line");
define("LAN_ONLINE_11", "Utenti totali Registrati");
define("LAN_ONLINE_ADMIN_1", "dal menu lastseen");
define("LAN_ONLINE_ADMIN_2", "Menu di didascalia lastseen");
define("LAN_ONLINE_ADMIN_3", "Numero di record da visualizzare");
define("LAN_ONLINE_ADMIN_4", "menu on-line");
define("LAN_ONLINE_ADMIN_5", "Menu on-line di didascalia");
define("LAN_ONLINE_ADMIN_6", "Visualizza elenco di membri online?");
define("LAN_ONLINE_ADMIN_7", "Visualizza elenco esteso di clientes online?");
define("LAN_ONLINE_ADMIN_8", "Visualizza un elenco separato da virgole dei membri.");
define("LAN_ONLINE_ADMIN_9", "Visualizza la lista degli utenti che visualizzano la pagina");
define("LAN_ONLINE_ADMIN_10", "Visualizza i visitatori connessi");


?>