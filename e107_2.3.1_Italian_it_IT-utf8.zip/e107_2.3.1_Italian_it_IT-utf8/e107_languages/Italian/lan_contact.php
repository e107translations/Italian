<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/03/30 05:11:15
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/
define("LANCONTACT_00", "Contattaci");
define("LANCONTACT_01", "Dati di contatto");
define("LANCONTACT_02", "Modulo di contatto");
define("LANCONTACT_03", "Inserisci il tuo nome:");
define("LANCONTACT_04", "Inserisci il tuo indirizzo di posta elettronica:");
define("LANCONTACT_05", "Oggetto del messaggio:");
define("LANCONTACT_06", "Messaggio:");
define("LANCONTACT_07", "Una copia di questo messaggio al tuo indirizzo di posta elettronica");
define("LANCONTACT_08", "Invia");
define("LANCONTACT_09", "Il tuo messaggio è stato inviato.");
define("LANCONTACT_10", "C'era un problema l'invio del messaggio.");
define("LANCONTACT_11", "Il tuo indirizzo email non sembra di essere valid.\\nPlease check it e riprovare.");
define("LANCONTACT_12", "Il tuo messaggio è troppo breve.");
define("LANCONTACT_13", "Si prega di includere un oggetto.");
define("LANCONTACT_14", "Invia messaggio a:");
define("LANCONTACT_15", "Codice errato inserito");
define("LANCONTACT_16", "Si deve essere [registrati] e firmato-in per utilizzare questo modulo.");
define("LANCONTACT_17", "Inserisci il tuo nome");
define("LANCONTACT_18", "Inserisci il tuo indirizzo email");
define("LANCONTACT_19", "Inserisci l'oggetto della email");
define("LANCONTACT_20", "Inserisi il tuo messaggio");
define("LANCONTACT_21", "Autorizzo il sito web a memorizzare le informazioni che invio con il form al fine di gestire correttamente la mia richiesta");
define("LANCONTACT_22", "Policy Privacy");
define("LANCONTACT_23", "Puoi leggere le nostre policy e le regole sulla privacy qui: [x]");
define("LANCONTACT_24", "Accordo GDPR");
