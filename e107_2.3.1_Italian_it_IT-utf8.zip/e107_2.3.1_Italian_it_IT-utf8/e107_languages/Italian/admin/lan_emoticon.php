<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("EMOLAN_1", "Emote attivazione");
define("EMOLAN_3", "EMote");
define("EMOLAN_4", "Attivare le emoticon?");
define("EMOLAN_5", "Immagine");
define("EMOLAN_6", "Emote codice");
define("EMOLAN_7", "separare più voci con spazi");
define("EMOLAN_11", "Attiva pacchetto");
define("EMOLAN_13", "Pacchetti installati");
define("EMOLAN_17", "Che hai un emoticon pack presente che contiene spazi nel nome, che non sono ammessi!");
define("EMOLAN_18", "Si prega di rinominare le istanze elencate di seguito così non contengono spazi");
define("EMOLAN_20", "Posizione");
define("EMOLAN_21", "Errore di lettura del Pack");
define("EMOLAN_22", "Nuove emoticon pack trovato");
define("EMOLAN_23", "Emote nuovo pacchetto xml trovato");
define("EMOLAN_24", "Nuove emoticon pack php trovato");
define("EMOLAN_26", "Rianalizzare pack");
define("EMOLAN_27", "Errore durante l'elaborazione pack");
define("EMOLAN_28", "Generare XML");
define("EMOLAN_29", "File XML generato");
define("EMOLAN_30", "Errore durante la scrittura di file XML");
define("EMOLAN_PAGE_TITLE", "Emoticon");
define("EMOLAN_31", "File totale [x] trovati");
define("EMOLAN_32", "Pack sconosciuto rilevato");
define("EMOLAN_33", "Formato di File XML non supportati");
define("EMOLAN_34", "File mancanti per pack");
define("EMOLAN_35", "-eliminati nel database");
define("EMOLAN_37", "Emote non impostato");
define("EMOLAN_38", "Emote vuoto valore");
