<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/07 23:51:42
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("WMLAN_00", "Messaggi di benvenuto");
define("WMLAN_05", "Racchiudere");
define("WMLAN_06", "Quando attivata, il messaggio verrà visualizzato all'interno di una scatola");
define("WMLAN_07", "Eseguire l'override di sistema standard per utilizzare {WMESSAGE} shortcode:");
define("WMLAN_11", "Incluso con Carosello");
define("WMLAN_12", "Aiuto Messaggio di Benvenuto");
define("WMLAN_13", "Questa pagina consente di impostare un messaggio che verrà visualizzato nella parte superiore della prima pagina per tutto il tempo che è attivato. È possibile impostare un messaggio diverso per gli ospiti, utenti registrati / registrati e amministratori.");


?>