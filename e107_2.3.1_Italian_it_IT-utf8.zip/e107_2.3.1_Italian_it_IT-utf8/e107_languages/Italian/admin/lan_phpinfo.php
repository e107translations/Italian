<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/08 00:07:27
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/
define("PHP_LAN_1", "Se si dispone di Curl attivo, si dovrebbe considerare di disabilitare questa funzione.");
define("PHP_LAN_2", "Questo è un rischio nella sicurezza e non è necessario per e107");
define("PHP_LAN_3", "Su un server di produzione, è meglio disattivare la visualizzazione degli errori nel browser.");
define("PHP_LAN_4", "La disattivazione di questa nasconderà la tua versione di PHP da browser.");
define("PHP_LAN_5", "Questo è un rischio per la sicurezza e dovrebbe essere disattivato.");
define("PHP_LAN_6", "[b] session.save_path [/ b] non è scrivibile! Questo può causare gravi problemi con il tuo sito");
define("PHP_LAN_7", "Problemi di configurazione PHP trovati: ");
define("PHP_LAN_8", "[x] manca e deve essere installato. ");
