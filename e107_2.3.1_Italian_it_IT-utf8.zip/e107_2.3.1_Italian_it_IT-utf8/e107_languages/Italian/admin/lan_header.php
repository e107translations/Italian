<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_HEADER_01", "Navigazione di admin");
define("LAN_HEADER_02", "Il server non consente caricamenti HTTP file quindi non sarà possibile per gli utenti di caricare avatar/file ecc. Per rettificare questo set file_uploads a su nel tuo php. ini e riavviare il server. Se non hai accesso al tuo contatto di php. ini i padroni di casa.");
define("LAN_HEADER_03", "Il server è in esecuzione con una restrizione di basedir in vigore. Questo non consente l'utilizzo di qualsiasi file di fuori della vostra home directory e come tale potrebbe interessare alcuni script come gestore dei file.");
define("LAN_HEADER_04", "Area Admin");
define("LAN_HEADER_05", "lingua visualizzata nell'area di admin");
define("LAN_HEADER_06", "Info plugin");
