<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/07 21:42:24
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("LCLAN_19", "Collegamento di tipo aperto");
define("LCLAN_20", "Si apre nella stessa finestra");
define("LCLAN_23", "Si apre in una nuova finestra");
define("LCLAN_24", "Si apre in mini-finestra 600 x 400");
define("LCLAN_78", "Mostra la descrizione come suggerimento di schermo");
define("LCLAN_79", "Descrizione verrà mostrato quando il mouse passa sopra il link");
define("LCLAN_80", "Attivare espansione sotto-menu");
define("LCLAN_81", "Sotto-menu verranno visualizzato solo dopo aver cliccato loro padre. (Padre di link è disabilitato)");
define("LCLAN_105", "Funzione");
define("LCLAN_106", "Di proprietà di");
define("LCLAN_107", "Consentono di eseguire l'override URL con un URL di Search-Engine-Friendly creati dinamicamente");
define("LCLAN_108", "Alcune selezioni omessi - non è possibile impostare Link come un Sublink della sua Sublink.");
define("LCLAN_109", "Si prega di scegliere un genitore");
define("LCLAN_110", "Si prega di scegliere un modulo di generazione");
define("LCLAN_111", "Dati del modulo non valido generatore");
define("LINKLAN_1", "Si apre in finestra 800 x 600");
define("LINKLAN_4", "Generatore di Sublink");
define("LINKLAN_5", "Generare Sublinks");
define("LINKLAN_6", "Creare sublinks da");
define("LINKLAN_7", "Creare sublinks sotto quale collegamento?");
define("LINKLAN_8", "Categorie News");
define("LINKLAN_9", "Categorie download");
define("LINKLAN_10", "Codice abbreviato per il Tema");


?>