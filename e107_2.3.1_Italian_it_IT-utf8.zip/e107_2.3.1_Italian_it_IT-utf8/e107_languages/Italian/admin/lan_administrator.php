<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/07 16:08:31
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/
define("ADMSLAN_6", "è l'amministratore del sito principale e non può essere eliminato.");
define("ADMSLAN_13", "Amministratori esistenti");
define("ADMSLAN_16", "Nome admin");
define("ADMSLAN_18", "Autorizzazioni");
define("ADMSLAN_21", "Modificare le autorizzazioni di amministratore");
define("ADMSLAN_25", "Upload / gestione dei file");
define("ADMSLAN_27", "Supervisionare le categorie di link");
define("ADMSLAN_41", "Creare e modificare menu personalizzati");
define("ADMSLAN_42", "Post Commenti");
define("ADMSLAN_52", "Amministratore di aggiornamento");
define("ADMSLAN_56", "Amministratore del sito");
define("ADMSLAN_58", "Amministratore del sito principale");
define("ADMSLAN_59", "Rimuovere lo Status di Admin");
define("ADMSLAN_61", "Amministratore eliminato");
define("ADMSLAN_62", "Gestore Plugin");
define("ADMSLAN_71", "Clicca qui per visualizzare i privilegi");
define("ADMSLAN_72", "ID admin: [x] nome: [y]  nuove autorizzazioni:");
define("ADMSLAN_73", "ID admin: [x] nome: [y]");
