<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("UDALAN_1", "Errore - si prega di inviare nuovamente.");
define("UDALAN_2", "Admin impostazioni aggiornate");
define("UDALAN_3", "Impostazioni aggiornate per");
define("UDALAN_4", "Nome");
define("UDALAN_6", "Digitare nuovamente la password");
define("UDALAN_7", "Cambia password");
define("UDALAN_8", "Password aggiornato per");
