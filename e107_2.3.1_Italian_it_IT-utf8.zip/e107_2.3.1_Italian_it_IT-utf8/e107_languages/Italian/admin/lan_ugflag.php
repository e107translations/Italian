<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("UGFLAN_2", "Attivare il flag di manutenzione");
define("UGFLAN_4", "Impostazione di manutenzione");
define("UGFLAN_5", "Testo da visualizzare quando sito giù");
define("UGFLAN_6", "Lasciare vuoto per visualizzare il messaggio predefinito");
define("UGFLAN_8", "Limitare l'accesso solo agli amministratori");
define("UGFLAN_9", "Limitare l'accesso al Main-Admins solo");
