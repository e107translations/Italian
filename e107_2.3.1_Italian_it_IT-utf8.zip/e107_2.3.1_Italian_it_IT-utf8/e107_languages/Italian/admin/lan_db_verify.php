<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("DBVLAN_1", "Impossibile leggere il file di dati di sql<br><br>Si prega di garantire che il file <b>core_sql.php</b> presente nella directory <b>/e107_core/sql</b> .");
define("DBVLAN_4", "Tabella");
define("DBVLAN_5", "Campo");
define("DBVLAN_6", "Stato");
define("DBVLAN_7", "Note");
define("DBVLAN_8", "Mancata corrispondenza");
define("DBVLAN_9", "Attualmente");
define("DBVLAN_10", "dovrebbe essere");
define("DBVLAN_11", "Campo mancante!");
define("DBVLAN_12", "Campo aggiuntivo!");
define("DBVLAN_13", "Tabella mancante!");
define("DBVLAN_14", "Scegliere la tabella o le tabelle per convalidare");
define("DBVLAN_15", "Inizio verificare");
define("DBVLAN_16", "Verifica SQL");
define("DBVLAN_19", "Tentare di risolvere");
define("DBVLAN_21", "Difficoltà gli elementi selezionati");
define("DBVLAN_22", "[x] non è leggibile");
define("DBVLAN_23", "Utilità database");
define("DBVLAN_24", "Si prega di selezionare azione.");
define("DBVLAN_25", "Indice mancante!");
define("DBVLAN_26", "[x] tabelle hanno problemi.");
