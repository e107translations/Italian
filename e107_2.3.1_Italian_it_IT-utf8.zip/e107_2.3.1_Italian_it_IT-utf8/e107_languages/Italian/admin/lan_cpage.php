<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/07 16:12:40
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/
define("CUSLAN_1", "Panoramica");
define("CUSLAN_2", "Titolo Pagina");
define("CUSLAN_3", "Articoli per Pagina");
define("CUSLAN_4", "Campi Personalizzati");
define("CUSLAN_5", "(Nuovo Lavoro)");
define("CUSLAN_9", "Testo");
define("CUSLAN_11", "Meta-descrizione");
define("CUSLAN_12", "Creare Menu di pagina");
define("CUSLAN_29", "Elenco di pagine se nessuna pagina selezionata");
define("CUSLAN_30", "Data di scadenza per cookie (in secondi)");
define("CUSLAN_31", "Creare menu");
define("CUSLAN_48", "Pagina elenco");
define("CUSLAN_49", "Lista dei menu");
define("CUSLAN_50", "Elenco libri/capitoli");
define("CUSLAN_51", "Aggiungi libro/capitolo");
define("CUSLAN_52", "Libro");
define("CUSLAN_53", "Libro o titolo di capitolo");
define("CUSLAN_55", "Può essere modificato da");
define("CUSLAN_56", "Padre");
define("CUSLAN_57", "Si prega di scegliere stringa univoca SEF URL per questa voce.");
define("CUSLAN_58", "Visualizza pagine in questo capitolo");
define("CUSLAN_59", "Pagina");
define("CUSLAN_60", "Pagina Opzioni");
define("CUSLAN_61", "Dal menu");
define("CUSLAN_62", "Opzioni del menu");
define("CUSLAN_63", "Libro/capitolo");
define("CUSLAN_64", "Nome del menu");
define("CUSLAN_65", "Titolo del menu");
define("CUSLAN_66", "Corpo del menu");
define("CUSLAN_67", "Modello del menu");
define("CUSLAN_68", "Testo pulsante personalizzato");
define("CUSLAN_69", "Pulsante personalizzato URL");
define("CUSLAN_70", "Icona/icona di menu");
define("CUSLAN_71", "Dal menu immagine/Video");
define("CUSLAN_72", "Modello di elenco libri/capitoli");
define("CUSLAN_73", "Menu creato");
define("CUSLAN_74", "Menu ' aggiornato");
define("CUSLAN_75", "Menu-id mancante rilevato:");
define("CUSLAN_76", "Menu con percorso n.");
define("CUSLAN_77", "cancellato");
define("CUSLAN_78", "Non poteva eliminare il menu con il percorso");
define("CUSLAN_79", "E' necessario inserire un titolo della pagina o il nome del menù");
define("CUSLAN_80", "Sottotitolo");
