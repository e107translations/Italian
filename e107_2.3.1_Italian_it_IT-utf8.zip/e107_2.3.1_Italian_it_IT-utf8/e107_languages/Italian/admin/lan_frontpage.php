<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/07 21:28:08
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("FRTLAN_13", "Impostazioni correnti di Front Page");
define("FRTLAN_30", "Custom pagina");
define("FRTLAN_35", "Pagina di post-login");
define("FRTLAN_42", "Aggiungi nuova regola");
define("FRTLAN_43", "Classe");
define("FRTLAN_46", "Modificare la regola esistente");
define("FRTLAN_49", "Home Page");
define("FRTLAN_51", "Altri");
define("FRTLAN_PAGE_TITLE", "Prima pagina");
define("FRTLAN_56", "definizione duplicata per classe:");
define("FRTLAN_57", "Errore del software");
define("FRTLAN_61", "Seleziona");


?>