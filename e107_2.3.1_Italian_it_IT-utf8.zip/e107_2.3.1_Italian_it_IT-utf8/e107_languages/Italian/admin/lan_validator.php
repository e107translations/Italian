<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_VALIDATE_0", "Errore sconosciuto");
define("LAN_VALIDATE_101", "Valore mancante");
define("LAN_VALIDATE_102", "Tipo di valore imprevisto");
define("LAN_VALIDATE_103", "Caratteri non validi trovati");
define("LAN_VALIDATE_104", "Non un indirizzo email valido");
define("LAN_VALIDATE_105", "Campi Don 'partita t");
define("LAN_VALIDATE_131", "Stringa troppo corta");
define("LAN_VALIDATE_132", "Stringa troppo lunga");
define("LAN_VALIDATE_133", "Numero troppo basso");
define("LAN_VALIDATE_134", "Numero troppo alto");
define("LAN_VALIDATE_135", "Conteggio di matrice troppo basso");
define("LAN_VALIDATE_136", "Conteggio di matrice troppo alto");
define("LAN_VALIDATE_151", "Numero di tipo integer previsto");
define("LAN_VALIDATE_152", "Numero di tipo float previsto");
define("LAN_VALIDATE_153", "Tipo di istanza previsto");
define("LAN_VALIDATE_154", "Tipo di matrice previsto");
define("LAN_VALIDATE_191", "Valore vuoto");
define("LAN_VALIDATE_201", "File non esiste");
define("LAN_VALIDATE_202", "File non scrivibile");
define("LAN_VALIDATE_203", "File supera la dimensione di file consentiti");
define("LAN_VALIDATE_204", "Dimensione del file inferiore dimensione file minima consentita");
define("LAN_VALIDATE_FAILMSG", "[x] errore di convalida: [y] [z].");
