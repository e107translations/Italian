<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/07 23:56:00
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/
define("UPLLAN_1", "Upload rimosso dall'elenco.");
define("UPLLAN_2", "Impostazioni salvate nel database");
define("UPLLAN_4", "Nulla è cambiato - non aggiornato");
define("UPLLAN_5", "Poster");
define("UPLLAN_7", "Sito Web");
define("UPLLAN_14", "Demo");
define("UPLLAN_16", "copiare newspost");
define("UPLLAN_17", "rimuovere il caricamento dall'elenco");
define("UPLLAN_18", "Vedi i dettagli");
define("UPLLAN_19", "Non ci sono Nessun upload pubblici non moderato");
define("UPLLAN_20", "Ci");
define("UPLLAN_21", "carica pubblica non moderato");
define("UPLLAN_24", "Tipo di file");
define("UPLLAN_25", "Upload abilitato?");
define("UPLLAN_26", "Nessun upload pubblici sarà consentito se disattivato");
define("UPLLAN_27", "non moderato upload pubblici");
define("UPLLAN_33", "Dimensione massima del file");
define("UPLLAN_34", "Dimensione massima assoluta di caricamento in byte. Più ulteriormente limitato dalle impostazioni di php. ini e dalle impostazioni in filetypes.xml");
define("UPLLAN_37", "Autorizzazione");
define("UPLLAN_38", "Selezionare questa opzione per consentire solo a determinati utenti di caricare");
define("UPLLAN_41", "Si prega di notare - upload di file sono disattivate dal tuo php. ini, non sarà possibile caricare file fino a quando non venga impostata su.");
define("UPLLAN_45", "Sei sicuro di che voler eliminare il seguente file...");
define("UPLAN_COPYTODLM", "copia download manager");
define("UPLAN_IS", "è");
define("UPLAN_ARE", "sono");
define("UPLAN_COPYTODLS", "Copiare la pagina di download");
define("UPLLAN_51", "Elenco upload");
define("UPLLAN_52", "Questa pagina consente di creare un file per la gestione dei permessi dei file da inviare. Il file viene salvato in [x],e deve essere copiato in [y] prima che la modifica  abbia effetto");
define("UPLLAN_54", "Estensioni di file");
define("UPLLAN_55", "Max carica dimensione");
define("UPLLAN_56", "Generare file");
define("UPLLAN_57", "Fonte per i valori:");
define("UPLLAN_59", "Impostazioni scritte");
define("UPLLAN_60", "Ora spostare questo file per");
define("UPLLAN_61", "Errore scrittura file:");
define("UPLLAN_62", "Scarica il plugin non è installato - attivazione non è possibile.");
define("UPLLAN_63", "Record spostato ai download. [x]");
define("UPLLAN_64", "Il gestore di Download");
define("UPLLAN_66", "Scarica percorso errore");
define("UPLLAN_68", "Errore SQL:");
define("UPLLAN_69", "Importato");
define("UPLLAN_70", "Inviato a [x]");
