<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/07 21:34:31
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/
define("LAN_CHECK_2", "Verificare");
define("LAN_CHECK_3", "Verifica della");
define("LAN_CHECK_4", "File mancante!");
define("LAN_CHECK_5", "Frase mancante!");
define("LAN_CHECK_15", "Caratteri non validi o spazi trovati prima [x] o [y]");
define("LAN_CHECK_16", "File originale");
define("LAN_CHECK_17", "Un problema di scrittura si è verificato durante il tentativo di salvare il file.");
define("LAN_CHECK_18", "File di lingua nel formato standard non sono disponibili per questo plugin/tema.");
define("LAN_CHECK_19", "Non-UTF-8 caratteri trovati!");
define("LAN_CHECK_20", "Generare il Language Pack");
define("LAN_CHECK_21", "Verificare di nuovo");
define("LAN_CHECK_23", "Errori trovati");
define("LAN_CHECK_26", "Fronte");
define("LAN_CHECK_PAGE_TITLE", "Lingue");
define("LAN_CHECK_27", "Numero di language pack errori trovati");
define("LAN_CHECK_28", "Identico");
define("LAN_CHECK_29", "Stringa identica (solo avviso)");
define("LAN_CHECK_30", "BBcode  mancanti");
define("LAN_CHECK_31", "Caratteri mancanti [e/oppure]");
define("LAN_CHECK_32", "Tags HTML mancanti");
define("LANG_LAN_23", "Creare Language-Pack (zip)");
define("LANG_LAN_30", "Data di rilascio");
define("LANG_LAN_31", "Compatibilità");
define("LANG_LAN_35", "I seguenti language pack sono disponibili per questa versione di e107.");
define("LANG_LAN_111", "Data di rilascio");
define("LANG_LAN_112", "Compatibile");
define("LANG_LAN_114", "Scarica Pack");
define("LANG_LAN_115", "Si prega di verificare e correggere il restante [x] errori prima di tentare di creare un language pack.");
define("LANG_LAN_116", "Si prega di verificare i file di lingua ('verifica') quindi riprovare.");
define("LANG_LAN_117", "È necessario correggere gli errori rimanenti prima di contribuire il language pack.");
define("LANG_LAN_119", "Si prega di controllare che CORE_LC e CORE_LC2 hanno valori in [x] e riprovare.");
define("LANG_LAN_120", "Si prega di assicurarsi di si utilizza nomi di cartella predefiniti in e107_config.php (ad es. e107_languages /, e107_plugins / etc.) e riprovare.");
define("LANG_LAN_AGR", "Nota: Utilizzando questi strumenti accetti di condividere un tuo file di lingua con la comunità di e107.");


?>