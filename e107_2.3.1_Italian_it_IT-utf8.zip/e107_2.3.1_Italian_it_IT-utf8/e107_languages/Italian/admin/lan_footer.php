<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("FOOTLAN_1", "Sito");
define("FOOTLAN_2", "Responsabile amministrazione");
define("FOOTLAN_3", "Versione");
define("FOOTLAN_4", "compilazione");
define("FOOTLAN_5", "Tema di admin");
define("FOOTLAN_6", "da");
define("FOOTLAN_7", "Info");
define("FOOTLAN_8", "Data di installazione");
define("FOOTLAN_9", "Server");
define("FOOTLAN_10", "host");
define("FOOTLAN_11", "Versione di PHP");
define("FOOTLAN_12", "MySQL");
define("FOOTLAN_13", "Info sito");
define("FOOTLAN_14", "Mostra documenti");
define("FOOTLAN_15", "Documentazione");
define("FOOTLAN_16", "Database");
define("FOOTLAN_17", "Set di caratteri");
define("FOOTLAN_18", "Tema del sito");
define("FOOTLAN_19", "Ora del server");
define("FOOTLAN_20", "Livello di protezione");
