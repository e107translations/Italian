<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("MESSLAN_1", "Messaggi ricevuti");
define("MESSLAN_2", "Elimina messaggio");
define("MESSLAN_3", "Messaggio eliminato.");
define("MESSLAN_4", "Eliminare tutti i messaggi");
define("MESSLAN_5", "Confermare");
define("MESSLAN_6", "Tutti i messaggi eliminati.");
define("MESSLAN_7", "Nessun messaggio.");
define("MESSLAN_8", "Tipo di messaggio");
define("MESSLAN_9", "Segnalato su");
define("MESSLAN_10", "Inserite");
define("MESSLAN_11", "si apre in una nuova finestra");
define("MESSLAN_12", "Messaggio");
define("MESSLAN_13", "Link");
