<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("FMLAN_12", "file");
define("FMLAN_13", "file");
define("FMLAN_14", "Directory");
define("FMLAN_15", "Directory");
define("FMLAN_16", "Directory principale");
define("FMLAN_18", "Dimensioni");
define("FMLAN_19", "Per l'ultima volta");
define("FMLAN_21", "Caricare file a questo dir");
define("FMLAN_22", "Caricare");
define("FMLAN_29", "Percorso");
define("FMLAN_30", "Salire di livello");
define("FMLAN_31", "cartella");
define("FMLAN_32", "Selezionare Directory");
define("FMLAN_34", "Scelta di directory");
define("FMLAN_35", "Directory dei file");
define("FMLAN_38", "File spostato con successo a");
define("FMLAN_39", "Impossibile spostare file di");
define("FMLAN_40", "Newspost-immagini di repertorio");
define("FMLAN_43", "Eliminare i file selezionati");
define("FMLAN_46", "Si prega di confermare che si desidera eliminare i file selezionati.");
define("FMLAN_47", "Upload utente");
define("FMLAN_48", "Spostare selezionato per");
define("FMLAN_49", "Si prega di confermare che si desidera spostare i file selezionati.");
define("FMLAN_50", "Spostare");
define("FMLAN_51", "Errore non identificato");
