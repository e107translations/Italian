<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("FLALAN_2", "Nessun tentativo di accesso non è stato registrato");
define("FLALAN_3", "Tentativo di eliminare");
define("FLALAN_4", "Utente ha tentato di effettuare il login utilizzando username/password errata");
define("FLALAN_5", "IP (s) vietato");
define("FLALAN_7", "Dati");
define("FLALAN_8", "Indirizzo IP / Host");
define("FLALAN_10", "Elimina / Ban controllato voci");
define("FLALAN_15", "Gli indirizzi IP seguenti sono stati auto-bandito - utente tentato più di dieci accessi non riusciti");
define("FLALAN_16", "Elimina questo elenco di divieto automatico");
define("FLALAN_17", "Lista auto-divieto cancellato");
define("FLALAN_18", "Potrebbe non ban IP indirizzo - IP-- - su whitelist");
