<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("SEALAN_1", "Configurazione di ricerca");
define("SEALAN_3", "Ricerca metodo sort:");
define("SEALAN_7", "Membri registrati");
define("SEALAN_10", "Visualizzare il valore di pertinenza:");
define("SEALAN_11", "Consente di selezionare aree ricercabile:");
define("SEALAN_12", "Limitare il tempo consentito tra le ricerche (max 5 minuti):");
define("SEALAN_13", "Limitare alla ricerca ogni");
define("SEALAN_14", "secondi");
define("SEALAN_15", "Pagina di ricerca accessibile alla classe utente");
define("SEALAN_18", "Ricercabile aree commenti (quando viene attivata la ricerca di commenti)");
define("SEALAN_19", "Consentire agli utenti di cercare più di una zona alla volta:");
define("SEALAN_20", "Impostazioni generali");
define("SEALAN_21", "Aree di ricerca");
define("SEALAN_23", "Alternativa");
define("SEALAN_25", "Userclass");
define("SEALAN_26", "Testo del pre-titolo");
define("SEALAN_30", "Evidenziare le parole chiave su cui per pagina:");
define("SEALAN_31", "Limitato a PHP");
define("SEALAN_32", "risultati (lasciare vuoto per nessun limite)");
define("SEALAN_35", "Metodo di selezione dei settori ricercabile:");
define("SEALAN_36", "A discesa");
define("SEALAN_37", "Casella di controllo");
define("SEALAN_38", "Radio");
define("SEALAN_39", "Pagine personalizzate");
define("SEALAN_40", "Opzioni di ricerca");
define("SEALAN_41", "Principale pagina");
define("SEALAN_43", "Modificare le impostazioni di ricerca per");
define("SEALAN_44", "Classe utente consentito per questa area di ricerca");
define("SEALAN_45", "Numero di risultati visualizzati per pagina");
define("SEALAN_46", "Numero di caratteri nel riepilogo del risultato di ricerca");
define("SEALAN_47", "Corrispondere solo parole intere:");
define("SEALAN_48", "Questa impostazione si applica solo quando il metodo di ordinamento ricerca è PHP. Se il tuo sito include Ideographic lingue quali il cinese e giapponese, è necessario disporre di questo impostato su off.");
define("SEALAN_49", "Se il tuo sito include lingue ideografiche, ad esempio cinese e giapponese, è necessario utilizzare il metodo sort PHP.");
