<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/11/07 23:47:28
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("NA_LAN_1", "L'Amministratore ha aggiornato la propria password");
define("NA_LAN_2", "L'Ammnistratore ha creato un nuovo utentee");
define("NA_LAN_3", "L'Amministratore ha attivato un nuovo utente");
define("NT_LAN_1", "Notificare");
define("NT_LAN_2", "Ricevere email di notifica su");
define("NU_LAN_1", "Eventi utente");
define("NU_LAN_2", "Registrazione utente");
define("NU_LAN_3", "Verifica dell'account utente");
define("NU_LAN_4", "Login utente");
define("NU_LAN_5", "Logout utente");
define("NU_LAN_6", "Login utente da socialnetwork");
define("NU_LAN_7", "Registrazione utente da socialnetwork");
define("NU_LAN_8", "Visualizza il profilo utente");
define("NU_LAN_9", "Modifica il profilo utente");
define("NS_LAN_1", "Eventi di protezione");
define("NS_LAN_2", "IP bannato per allagamento sito");
define("NS_LAN_3", "IP bannato per molteplici tentativi di autenticazione");
define("NN_LAN_1", "News eventi");
define("NN_LAN_2", "Notizie articolo presentato da utente");
define("NN_LAN_3", "Notizie articolo pubblicate da admin");
define("NN_LAN_4", "Notizie articolo modificate da admin");
define("NN_LAN_5", "Notizie voce soppressa da admin");
define("NN_LAN_6", "Notifica News attivata");
define("NM_LAN_1", "Eventi posta");
define("NM_LAN_2", "Email massive completate");
define("NM_LAN_3", "Indirizzo Email =>");
define("NF_LAN_1", "File eventi");
define("NF_LAN_2", "File caricato dall'utente");
define("LAN_NOTIFY_01", "Eventi");


?>