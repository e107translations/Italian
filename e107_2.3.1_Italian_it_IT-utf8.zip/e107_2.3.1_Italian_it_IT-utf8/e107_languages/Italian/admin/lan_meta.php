<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2021/03/14 01:16:52
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("METLAN_00", "Meta tag");
define("METLAN_1", "Ulteriori modifiche del meta");
define("METLAN_2", "ad es.< meta='' name='revisit-after' content='30 days'>");
define("METLAN_3", "Utilizzare notizie titolo e riassunto come meta-descrizione sulle pagine di notizie.");
define("METLAN_4", "Tag personalizzati (nel tag [x]) ");
define("METLAN_5", "Tag personalizzati (dopo [x]) ");
define("METLAN_6", "Tag personalizzati (prima di [x]) ");
define("METLAN_7", "Eventuali metadati o tag HTML personalizzati inseriti qui (come i tag <script> o il codice di Google Analytics) verranno inclusi in ogni pagina del sito web nelle aree designate. ");
