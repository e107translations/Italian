<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/07 16:25:00
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/
define("LAN_UPDATE_2", "Azione");
define("LAN_UPDATE_3", "Non necessaria");
define("LAN_UPDATE_4", "Aggiornare da [x] [y]");
define("LAN_UPDATE_5", "Aggiorna la struttura core del Database");
define("LAN_UPDATE_7", "Eseguito [x]");
define("LAN_UPDATE_12", "Una delle vostre tabelle contiene voci duplicate.");
define("LAN_UPDATE_13", "Aggiungere impostazioni di base mancanti o aggiuntivi");
define("LAN_UPDATE_14", "Avviare la versione:");
define("LAN_UPDATE_20", "Aggiornamento dei Preference(s):");
define("LAN_UPDATE_21", "L'aggiornamento di struttura della tabella:");
define("LAN_UPDATE_22", "Conversione serializzato Preference(s):");
define("LAN_UPDATE_23", "Aggiornare il percorso di Menu:");
define("LAN_UPDATE_24", "Eliminazione del campo tabella obsolete:");
define("LAN_UPDATE_25", "L'eliminazione di tabella obsoleta:");
define("LAN_UPDATE_26", "Estendere il campo dell'indirizzo IP:");
define("LAN_UPDATE_27", "Aggiunta di tabella:");
define("LAN_UPDATE_28", "spostate [x]  e-mail salvate");
define("LAN_UPDATE_29", "A seconda della particolare configurazione, potrebbe essere necessario eseguire il processo di aggiornamento più volte.");
define("LAN_UPDATE_37", "Aggiungi indice [x] alla tabella [y]");
define("LAN_UPDATE_38", "Aggiornare le impostazioni di pagina anteriore");
define("LAN_UPDATE_40", "Tabella di aggiornamento newsfeeds");
define("LAN_UPDATE_41", "Campo fuso orario utente elaborato");
define("LAN_UPDATE_42", "Errore di trasferimento di dati di fuso orario utente - interrotto");
define("LAN_UPDATE_43", "Rinominare la tabella dblog");
define("LAN_UPDATE_44", "Rinominare la tabella del log di rotolamento");
define("LAN_UPDATE_45", "Aggiunta nuova tabella al database:");
define("LAN_UPDATE_46", "Errore di lettura definizione di tabella:");
define("LAN_UPDATE_50", "Prefs obsoleto eliminati:");
define("LAN_UPDATE_51", "Aggiornare la definizione della tabella plugin:");
define("LAN_UPDATE_52", "Download aggiornamento tabella");
define("LAN_UPDATE_53", "Tabella di aggiornamento download mirror");
define("LAN_UPDATE_54", "Tabella [y]  mancante non è possibile aggiungere [x] indice");
define("LAN_UPDATE_55", "Descrizione");
define("LAN_UPDATE_56", "Aggiornamento del sistema");
define("LAN_UPDATE_57", "Prima di continuare, si prega di eliminare manualmente le seguenti cartelle obsoleti dal sistema:");
define("LAN_UPDATE_CAPTION_PLUGIN", "Aggiornamenti plugin");
define("LAN_UPDATE_CAPTION_CORE", "Aggiornamenti di base");
define("LAN_UPDATE_58", "Si consiglia vivamente di eseguire [File Inspector] dopo aver completato tutti gli aggiornamenti, al fine di rilevare eventuali file obsoleti che devono essere rimossi. ");
