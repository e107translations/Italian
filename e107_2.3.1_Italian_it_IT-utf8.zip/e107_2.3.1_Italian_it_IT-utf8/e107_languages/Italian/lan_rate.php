<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/07 12:34:55
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("RATELAN_0", "Voto");
define("RATELAN_1", "Voti");
define("RATELAN_2", "Come giudichi questo elemento?");
define("RATELAN_3", "Grazie per il voto!");
define("RATELAN_4", "Non valutato");
define("RATELAN_5", "Vota questo:");
define("RATELAN_6", "Effettua il login per votare questo.");
define("RATELAN_7", "Mi Piace");
define("RATELAN_8", "Non mi piace più");
define("RATELAN_9", "Hai già votato");
define("RATELAN_10", "Non è presente nessun ID per la valutazione");
define("RATELAN_11", "Valutazione non riuscita");
define("RATELAN_POOR", "Mediocre");
define("RATELAN_FAIR", "Discreto");
define("RATELAN_GOOD", "Buono");
define("RATELAN_VERYGOOD", "Molto buono");
define("RATELAN_EXCELLENT", "Eccellente");


?>