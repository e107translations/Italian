<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("NT_LAN_US_1", "Registrazione utente");
define("NT_LAN_UV_1", "Registrazione utente verificato");
define("NT_LAN_UV_2", "ID utente:");
define("NT_LAN_UV_3", "Nome di accesso utente:");
define("NT_LAN_UV_4", "Utente IP:");
define("NT_LAN_LI_1", "Utente connesso");
define("NT_LAN_LO_1", "Utente disconnesso");
define("NT_LAN_LO_2", "eseguito il logout dal sito");
define("NT_LAN_FL_1", "Divieto di inondazione");
define("NT_LAN_FL_2", "Indirizzo IP bannato per inondazioni");
define("NT_LAN_SN_1", "Notizie articolo presentato");
define("NT_LAN_ML_1", "Alla rinfusa email inviare completo");
define("NT_LAN_NU_1", "Aggiornato");
define("NT_LAN_ND_1", "Notizie voce soppressa");
define("NT_LAN_ND_2", "Id elemento eliminato notizie");
