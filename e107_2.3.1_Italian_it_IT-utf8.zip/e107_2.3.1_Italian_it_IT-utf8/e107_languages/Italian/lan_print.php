<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_PRINT_86", "Categoria:");
define("LAN_PRINT_87", "da");
define("LAN_PRINT_94", "Inviato da");
define("LAN_PRINT_135", "Notizia:");
define("LAN_PRINT_303", "Questa notizia è da");
define("LAN_PRINT_305", "Sottovoce:");
define("LAN_PRINT_306", "Questo è da:");
define("LAN_PRINT_307", "Stampa questa pagina");
define("LAN_PRINT_1", "stampante amichevole");
