<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/03/30 05:16:23
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("LAN_EFORM_001", "Premi sull'avatar per sostituirlo");
define("LAN_EFORM_002", "scegli l'avatar");
define("LAN_EFORM_003", "oppure");
define("LAN_EFORM_004", "scegli questo avatar");
define("LAN_EFORM_005", "Non sono presenti avatar");
define("LAN_EFORM_006", "Solo per Admin:
[br]La Directory [b][x][/b] 
è vuotaè[br] Invia alcuni avatar di default in questa cartella per permettere agli utenti di sceglierne uno.");
define("LAN_EFORM_007", "media Manager");
define("LAN_EFORM_008", "seleziona le colonne da visualizzare");
define("LAN_EFORM_009", "visualizza colonne");
define("LAN_EFORM_010", "vista veloce");
define("LAN_EFORM_011", "vai al profilo utente");
define("LAN_EFORM_012", "Campo Multi lingua");
define("LAN_EFORM_013", "vai alla lista");
define("LAN_EFORM_014", "crea un altro");
define("LAN_EFORM_015", "modifica il corrente");
define("LAN_EFORM_016", "invia dopo");


?>