<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/07 21:17:39
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("COMLAN_0", "[bloccato da admin]");
define("COMLAN_1", "Sbloccare");
define("COMLAN_2", "Blocco");
define("COMLAN_4", "Info");
define("COMLAN_5", "Commenti...");
define("COMLAN_6", "Devi essere loggato per fare commenti su questo sito - si prega di login o se non sei registrato clicca");
define("COMLAN_7", "Amministratore del sito principale");
define("COMLAN_8", "Commento");
define("COMLAN_9", "Invia commento");
define("COMLAN_10", "Amministratore");
define("COMLAN_11", "È riuscito a inserire il tuo commento nel database - Riscrivi lasciando tutti i caratteri non standard.");
define("COMLAN_12", "Utente");
define("COMLAN_16", "Nome utente:");
define("COMLAN_100", "Notizie");
define("COMLAN_101", "Sondaggio");
define("COMLAN_102", "Risposta a:");
define("COMLAN_103", "Articolo");
define("COMLAN_104", "Recensione");
define("COMLAN_105", "Contenuto");
define("COMLAN_106", "Scarica");
define("COMLAN_145", "Data di registrazione:");
define("COMLAN_194", "Guest");
define("COMLAN_195", "Membri registrati");
define("COMLAN_310", "Incapace di accettare il posto come tale nome utente è registrato - se è il tuo nome utente effettua il login per postare.");
define("COMLAN_312", "Post duplicato - Impossibile accettare.");
define("COMLAN_313", "Posizione");
define("COMLAN_314", "moderare i commenti");
define("COMLAN_315", "Trackbacks");
define("COMLAN_316", "Nessun trackbacks per questo newspost.");
define("COMLAN_317", "Trackbacks moderata");
define("COMLAN_318", "Modifica commento");
define("COMLAN_319", "modificato");
define("COMLAN_320", "Commento di aggiornamento");
define("COMLAN_321", "qui");
define("COMLAN_322", "per l'iscrizione");
define("COMLAN_323", "Errore!");
define("COMLAN_324", "Oggetto");
define("COMLAN_325", "Re:");
define("COMLAN_326", "Rispondere a questo");
define("COMLAN_328", "Commenti sono chiusi");
define("COMLAN_329", "Non autorizzato");
define("COMLAN_330", "IP:");
define("COMLAN_331", "In attesa di approvazione");
define("COMLAN_332", "Non poteva eliminare il commento");
define("COMLAN_333", "Commento approvato");
define("COMLAN_334", "Non poteva approvare il commento");
define("COMLAN_335", "Approvato");
define("COMLAN_336", "Si prega di scrivere qualcosa prima.");
define("COMLAN_337", "Aggiornato con successo.");
define("COMLAN_400", "approvato");
define("COMLAN_401", "bloccato");
define("COMLAN_402", "in sospeso");
define("COMLAN_403", "Lascia un messaggio...");
define("COMLAN_404", "Approva");
define("COMLAN_TYPE_1", "Notizie");
define("COMLAN_TYPE_2", "Scarica");
define("COMLAN_TYPE_3", "Domande frequenti");
define("COMLAN_TYPE_4", "sondaggio");
define("COMLAN_TYPE_5", "documenti");
define("COMLAN_TYPE_6", "bugtrack");
define("COMLAN_TYPE_7", "idee");
define("COMLAN_TYPE_8", "UserProfile");
define("COMLAN_TYPE_PAGE", "Contenuto");
define("COMLAN_500", "[Autenticati] per lasciare un messaggio");
define("COMLAN_501", "Non risulti ancora registrato [premi qui per la registrazione]");


?>