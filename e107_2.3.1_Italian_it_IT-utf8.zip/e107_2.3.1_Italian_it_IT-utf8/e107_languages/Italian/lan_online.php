<?php

/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/07 12:30:08
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("ONLINE_EL1", "Ospiti:");
define("ONLINE_EL2", "Membri:");
define("ONLINE_EL3", "In questa pagina:");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "Membri");
define("ONLINE_EL6", "Nuovo membro");
define("ONLINE_EL7", "visualizzazione");
define("ONLINE_EL8", "record presenze:");
define("ONLINE_EL9", "il");
define("ONLINE_EL10", "Nome del membro");
define("ONLINE_EL11", "Visualizzazione della pagina");
define("ONLINE_EL12", "Rispondendo a");
define("ONLINE_EL13", "Forum");
define("ONLINE_EL14", "Discussione");
define("ONLINE_EL15", "Pagina");
define("ONLINE_EL16", "Informazioni non disponibili");
define("CLASSRESTRICTED", "Pagina con limitazioni di classe");
define("CHAT", "Chat");
define("DOWNLOAD", "Download");
define("EMAIL", "email.php");
define("FORUM", "Indice del Forum principale");
define("LINKS", "Collegamenti");
define("NEWS", "Notizie");
define("OLDPOLLS", "Vecchi sondaggi");
define("POLLCOMMENT", "Sondaggio");
define("PRINTPAGE", "Stampa");
define("LOGIN", "Log-In");
define("SEARCH", "Ricerca");
define("STATS", "Statistiche del sito");
define("SUBMITNEWS", "Invia News");
define("UPLOAD", "Upload");
define("USERPAGE", "Profili utente");
define("USERSETTINGS", "Impostazioni utente");
define("ONLINE", "Utenti online");
define("LISTNEW", "Elenco nuovi elementi");
define("USERPOSTS", "Messaggi utente");
define("SUBCONTENT", "Invia contenuti");
define("TOP", "Top thread poster/più attivi");
define("ADMINAREA", "Area Admin");
define("BUGTRACKER", "Tracciare i Bug");
define("EVENT", "Elenco eventi");
define("CALENDAR", "Calendario degli eventi");
define("FAQ", "Domande frequenti");
define("PM", "Messaggi privati");
define("SURVEY", "Sondaggio");
define("ARTICLE", "Articolo");
define("CONTENT", "Contenuto della pagina");
define("REVIEW", "Recensione");
define("OTHER", "Altra pagina:");

//?>
