<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("US_LAN_1", "Selezionare utente");
define("US_LAN_2", "Selezionare utente classe");
define("US_LAN_3", "Tutti gli utenti");
define("US_LAN_4", "Trovare il nome utente");
define("US_LAN_5", "Utenti trovati");
define("US_LAN_6", "Ricerca");
