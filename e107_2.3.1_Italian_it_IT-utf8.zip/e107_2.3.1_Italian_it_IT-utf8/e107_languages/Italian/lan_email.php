<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/03/30 05:12:32
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("LAN_EMAIL_1", "Da:");
define("LAN_EMAIL_2", "Indirizzo IP del mittente:");
define("LAN_EMAIL_3", "Articolo inviato da");
define("LAN_EMAIL_4", "Inviare Email");
define("LAN_EMAIL_5", "Elemento di e-mail ad un amico");
define("LAN_EMAIL_6", "Ho pensato che potrebbe essere interessato in questo articolo da");
define("LAN_EMAIL_7", "Invia per e-mail");
define("LAN_EMAIL_8", "Commento");
define("LAN_EMAIL_9", "Sorry - Impossibile inviare e-mail");
define("LAN_EMAIL_10", "Posta inviata a");
define("LAN_EMAIL_11", "Email inviata");
define("LAN_EMAIL_13", "Articolo di e-mail ad un amico");
define("LAN_EMAIL_14", "News_item di e-mail ad un amico");
define("LAN_EMAIL_15", "Nome utente:");
define("LAN_EMAIL_106", "Che non sembra essere un indirizzo email valido");
define("LAN_EMAIL_185", "Invia articolo");
define("LAN_EMAIL_186", "Invia notizia");
define("LAN_EMAIL_187", "Indirizzo email per inviare a");
define("LAN_EMAIL_188", "Ho pensato che potrebbe essere interessato a questa storia di notizie da");
define("LAN_EMAIL_189", "Ho pensato che si potrebbe essere interessati a questo articolo da");
define("LAN_EMAIL_190", "Inserire il codice visibile");
define("LAN_SOCIAL_LINK_CHK", "Clicca sul link");


?>