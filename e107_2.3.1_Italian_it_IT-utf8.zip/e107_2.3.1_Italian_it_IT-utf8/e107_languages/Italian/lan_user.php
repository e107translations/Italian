<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/07 12:49:18
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/
define("LAN_USER_01", "Nome visualizzato");
define("LAN_USER_02", "Nome di login");
define("LAN_USER_03", "Vero nome");
define("LAN_USER_04", "Titolo personalizzato");
define("LAN_USER_06", "Fotografia");
define("LAN_USER_07", "Avatar");
define("LAN_USER_09", "Firma");
define("LAN_USER_10", "Nascondi e-mail");
define("LAN_USER_12", "Classe utente");
define("LAN_USER_13", "ID");
define("LAN_USER_14", "Data di registrazione");
define("LAN_USER_15", "Ultima visita");
define("LAN_USER_16", "Visita corrente");
define("LAN_USER_18", "Indirizzo IP");
define("LAN_USER_19", "Divieto di");
define("LAN_USER_20", "Prefs");
define("LAN_USER_21", "Visite");
define("LAN_USER_22", "Admin");
define("LAN_USER_23", "Perms");
define("LAN_USER_24", "Modifica della password");
define("LAN_USER_31", "Amministratore del sito principale");
define("LAN_USER_32", "Amministratore del sito");
define("LAN_USER_33", "Nessuna informazione");
define("LAN_USER_34", "fa");
define("LAN_USER_35", "[nascoste di richiesta]");
define("LAN_USER_36", "Clicca qui per Vista utente Commenti");
define("LAN_USER_37", "Clicca qui per Visualizza i messaggi nel Forum");
define("LAN_USER_38", "Clicca qui per aggiornare le informazioni");
define("LAN_USER_39", "Clicca qui per modificare le informazioni dell'utente");
define("LAN_USER_40", "membri precedenti");
define("LAN_USER_41", "membro successivo");
define("LAN_USER_42", "nessuna foto");
define("LAN_USER_43", "eliminare foto");
define("LAN_USER_44", "Varie");
define("LAN_USER_45", "DESC");
define("LAN_USER_46", "LS.");
define("LAN_USER_49", "Non sono disponibili informazioni per l'utente come non sono registrati presso");
define("LAN_USER_50", "Profilo membri");
define("LAN_USER_51", "Che non è un utente valido.");
define("LAN_USER_52", "Membri registrati");
define("LAN_USER_53", "Ancora non iscritti.");
define("LAN_USER_54", "Livello");
define("LAN_USER_55", "Non avete accesso a visualizzare questa pagina.");
define("LAN_USER_56", "Membri registrati:");
define("LAN_USER_57", "Ordine:");
define("LAN_USER_58", "Membri");
define("LAN_USER_59", "E ' entrato");
define("LAN_USER_60", "Indirizzo email:");
define("LAN_USER_62", "Invia messaggio privato");
define("LAN_USER_63", "Vero nome:");
define("LAN_USER_64", "Statistiche del sito");
define("LAN_USER_65", "Ultima visita");
define("LAN_USER_66", "Visite al sito dal registrazione");
define("LAN_USER_67", "Chatbox post");
define("LAN_USER_68", "Commento Pubblicato");
define("LAN_USER_69", "Messaggi nel forum");
define("LAN_USER_71", "Firma:");
define("LAN_USER_72", "Avatar:");
define("LAN_USER_73", "scelta di contenuto/mailing list");
define("LAN_USER_74", "Titolo personalizzato");
define("LAN_USER_75", "Il tuo [x] è obbligatorio");
define("LAN_USER_76", "Sottoscritto");
define("LAN_USER_77", "La password deve essere almeno [x] caratteri.");
define("LAN_USER_78", "Min.");
define("LAN_USER_79", "i caratteri.");
define("LAN_USER_80", "il nome visualizzato sul sito");
define("LAN_USER_81", "Nome utente:");
define("LAN_USER_82", "il nome si utilizza per effettuare il login al sito");
define("LAN_USER_83", "Nascondi indirizzo email?:");
define("LAN_USER_84", "Ciò impedirà il tuo indirizzo email venga visualizzato sul sito");
define("LAN_USER_85", "Se si desidera modificare il nome utente, è necessario chiedere un amministratore del sito");
define("LAN_USER_86", "Dimensione massima avatar è[x] - x [y] pixel");
define("LAN_USER_87", "Autenticati per valutare questo utente");
define("LAN_XUP_ERRM_01", "Registrazione  fallita. Questa funzionalità è disattivata.");
define("LAN_XUP_ERRM_02", "Registrazione fallita. Fornitore di hosting errato.");
define("LAN_XUP_ERRM_03", "Accesso fallito. Fornitore di hosting errato");
define("LAN_XUP_ERRM_04", "Registrazione fallita. Il nome utente risulta già registrato");
define("LAN_XUP_ERRM_05", "Registrazione fallita. L'Utente è già registrato. Utilizzata il login di accesso");
define("LAN_XUP_ERRM_06", "Accesso fallito! Non è  stata rilevato un indirizzo di posta elettronica.Non è possibile proseguire la registrazione senza indicare un account di posta.");
define("LAN_XUP_ERRM_07", "Socialnetwork login tester");
define("LAN_XUP_ERRM_08", "Per cortesia disconnettiti da e107 prima di testare la procedura di registrazione e login del nuovo utente");
define("LAN_XUP_ERRM_09", "Login test solo con [x]");
define("LAN_XUP_ERRM_10", "Registrazione / Login test con [x]");
define("LAN_XUP_ERRM_11", "Connesso:");
define("LAN_XUP_ERRM_12", "Prova il logout");
