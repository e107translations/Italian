<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/07 04:59:58
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/
define("LAN_LIBRARY_MANAGER_01", "La Libreria [x] , e la sua dipendenza  [y]  non sono installate");
define("LAN_LIBRARY_MANAGER_02", "La versione [x]  della libreria [y] non é compatibile con la libreria [z]");
define("LAN_LIBRARY_MANAGER_03", "La libreria [x] non é stata trovata");
define("LAN_LIBRARY_MANAGER_04", "Non é stato possibile trovare la libreria [x]");
define("LAN_LIBRARY_MANAGER_05", "La versione [x] della libreria i[y] nistallata non é supportata.");
define("LAN_LIBRARY_MANAGER_06", "La variante [x] della librerira [y] non é stata trovata.");
define("LAN_LIBRARY_MANAGER_07", "Manca la dipendenza");
define("LAN_LIBRARY_MANAGER_08", "Dipendenza incompatibile");
define("LAN_LIBRARY_MANAGER_10", "non rilevata");
define("LAN_LIBRARY_MANAGER_11", "non supportato");
define("LAN_LIBRARY_MANAGER_13", "Libreria");
define("LAN_LIBRARY_MANAGER_21", "Fornitore di Hosting");
define("LAN_LIBRARY_MANAGER_25", "Librerie terze parti");
define("LAN_LIBRARY_MANAGER_27", "Nome Server: [x]");
define("LAN_LIBRARY_MANAGER_28", "Percorso libreria: [x]");
define("LAN_LIBRARY_MANAGER_29", "Percorso libreria");
define("LAN_LIBRARY_MANAGER_30", "Setting CDN");
define("LAN_LIBRARY_MANAGER_31", "Utilizza il CDN per le librerie del nucleo");
define("LAN_LIBRARY_MANAGER_32", "CDN Provider");


?>