<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("TOP_LAN_0", "Forum Top poster");
define("TOP_LAN_1", "Nome utente");
define("TOP_LAN_2", "Post");
define("TOP_LAN_3", "Commento di top poster");
define("TOP_LAN_5", "Chatbox top poster");
define("TOP_LAN_6", "Valutazione del sito");
define("LAN_1", "Thread");
define("LAN_2", "Poster");
define("LAN_3", "Visualizzazioni");
define("LAN_4", "Risposte");
define("LAN_5", "Lastpost");
define("LAN_6", "Discussioni");
define("LAN_7", "Discussioni più attive");
define("LAN_8", "Top poster");
