<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("NP_1", "Pagina precedente");
define("NP_2", "Pagina successiva");
define("LAN_NP_FIRST", "prima");
define("LAN_NP_URLFIRST", "Vai alla prima pagina");
define("LAN_NP_PREVIOUS", "precedente");
define("LAN_NP_URLPREVIOUS", "Vai alla pagina precedente");
define("LAN_NP_NEXT", "successivo");
define("LAN_NP_URLNEXT", "Vai alla pagina successiva");
define("LAN_NP_LAST", "Ultimo");
define("LAN_NP_URLLAST", "Vai all'ultima pagina");
define("LAN_NP_GOTO", "Vai alla pagina [x]");
define("LAN_NP_URLCURRENT", "Attualmente hanno visto");
define("NP_CAPTION", "Pagina [x] [y]");
