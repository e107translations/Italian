<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/03/30 05:11:35
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/
define("LANDT_01", "anno");
define("LANDT_02", "mese");
define("LANDT_03", "settimana");
define("LANDT_04", "giorno");
define("LANDT_05", "ora");
define("LANDT_06", "minuto");
define("LANDT_07", "secondo");
define("LANDT_01s", "anni");
define("LANDT_02s", "mesi");
define("LANDT_03s", "settimane");
define("LANDT_04s", "giorni");
define("LANDT_05s", "ore");
define("LANDT_06s", "minuti");
define("LANDT_07s", "secondi");
define("LANDT_08", "minuto");
define("LANDT_08s", "minuti");
define("LANDT_09", "secondo");
define("LANDT_09s", "secondi");
define("LANDT_AGO", "fa");
define("LANDT_IN", "in");
define("LANDT_10", "Proprio Ora");
define("LANDT_XAGO", "[x] fa");
define("LANDT_INX", "in [x]");
