<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/07 12:50:32
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/
define("UC_LAN_0", "Tutti (pubblico)");
define("UC_LAN_1", "Ospiti");
define("UC_LAN_2", "Nessuno (inattivo)");
define("UC_LAN_3", "Membri");
define("UC_LAN_4", "Sola lettura");
define("UC_LAN_5", "Amministratore");
define("UC_LAN_6", "Amministratore principale");
define("UC_LAN_7", "Moderatori del forum");
define("UC_LAN_8", "Gli amministratori e Mods");
define("UC_LAN_9", "Nuovi utenti");
define("UC_LAN_10", "Motori di ricerca");
define("UC_LAN_INVERT", "Non  [x]");
define("UC_LAN_INVERTLABEL", "Tutti ma...");
