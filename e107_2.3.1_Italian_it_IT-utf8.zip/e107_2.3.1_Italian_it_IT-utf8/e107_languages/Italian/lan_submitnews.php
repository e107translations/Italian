<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/07 12:43:36
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "Invia News");
define("LAN_134", "Il tuo elemento è stato inviato per la revisione da uno degli amministratori del sito.");
define("LAN_135", "Notizia:");
define("LAN_136", "Invia notizia");
define("NWSLAN_10", "Nessuna categoria di notizie");
define("NWSLAN_11", "Non hai accesso in questa area o non ti sei autenticato.");
define("NWSLAN_12", "Accesso Negato");
define("SUBNEWSLAN_1", "È necessario includere un title.\\n");
define("SUBNEWSLAN_2", "È necessario includere alcuni testo nell'elemento notizie. \\n");
define("SUBNEWSLAN_3", "L'allegato deve essere un file gif o png, jpg");
define("SUBNEWSLAN_4", "File troppo grande");
define("SUBNEWSLAN_5", "File di immagine");
define("SUBNEWSLAN_6", "(jpg, gif o png)");
define("SUBNEWSLAN_7", "È necessario dare il vostro nome e indirizzo email");
define("SUBNEWSLAN_8", "Immagine di caricamento di errore");
define("SUBNEWSLAN_9", "Parole chiave");
define("SUBNEWSLAN_11", "Meta Descrizioni");
define("SUBNEWSLAN_12", "Utilizzato da Facebook");
define("SUBNEWSLAN_13", "URLs Media");


?>