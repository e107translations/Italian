<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("PAGE_NAME", "Sito temporaneamente chiuso");
define("LAN_SITEDOWN_00", "è temporaneamente chiuso");
define("LAN_SITEDOWN_01", "Abbiamo temporaneamente chiuso il sito per alcune operazioni indispensabili di manutenzione. Non ci vorrà troppo tempo - si prega controllare indietro presto, ci scusiamo per l'inconveniente.");
