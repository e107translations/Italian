<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/07 12:54:00
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Messaggi utente");
define("UP_LAN_0", "Tutti i messaggi del Forum per [x]");
define("UP_LAN_1", "Tutti i commenti per [x]");
define("UP_LAN_2", "Discussione");
define("UP_LAN_3", "Visualizzazioni");
define("UP_LAN_4", "Risposte");
define("UP_LAN_5", "Ultimo Post");
define("UP_LAN_6", "Discussioni");
define("UP_LAN_7", "Non ci sono commenti");
define("UP_LAN_8", "Nessun post");
define("UP_LAN_9", "il");
define("UP_LAN_10", "Re");
define("UP_LAN_11", "Pubblicato il");
define("UP_LAN_12", "Ricerca");
define("UP_LAN_14", "Messaggi nel forum");
define("UP_LAN_15", "Re");
define("UP_LAN_16", "Indirizzo IP");
