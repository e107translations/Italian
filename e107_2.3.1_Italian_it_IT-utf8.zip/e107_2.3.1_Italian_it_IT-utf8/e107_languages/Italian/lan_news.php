<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/04/07 12:27:34
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/
define("LAN_NEWS_1", "Notizie specifiche solo per i soci");
define("LAN_NEWS_2", "Non è consentito di vedere questa notizia");
define("LAN_NEWS_9", "Titolo è solo impostato - <b>verrà mostrato solo il titolo di notizie</b><br>");
define("LAN_NEWS_10", "Questo post di notizie è <b>inattivo</b> (non sulla prima pagina).");
define("LAN_NEWS_11", "Questo post di notizie è <b>attiva</b> (sulla prima pagina).");
define("LAN_NEWS_12", "Commenti sono attivati <b>su</b>.");
define("LAN_NEWS_13", "Commenti sono girati <b>fuori</b>.");
define("LAN_NEWS_14", "<br>Periodo di attivazione:");
define("LAN_NEWS_15", "Lunghezza del corpo:");
define("LAN_NEWS_16", "b. lunghezza estesa:");
define("LAN_NEWS_17", "b.");
define("LAN_NEWS_18", "Info:");
define("LAN_NEWS_19", "Ora");
define("LAN_NEWS_23", "Categorie News");
define("LAN_NEWS_24", "crea pdf di questa notizia");
define("LAN_NEWS_31", "Notizia appiccicoso");
define("LAN_NEWS_82", "News - categoria");
define("LAN_NEWS_83", "Nessuna novità in questo momento - si prega di riprovare presto.");
define("LAN_NEWS_84", "Ritornare alla pagina precedente news");
define("LAN_NEWS_85", "Torna alla panoramica delle categorie");
define("LAN_NEWS_86", "Notizie più vecchie");
define("LAN_NEWS_87", "News più recenti");
define("LAN_NEWS_462", "Nessun elemento di novità per mese specificato");
define("LAN_NEWS_463", "Non ci sono news per la categoria specificata - si prega di ricontrollare  a breve.");
define("LAN_NEWS_464", "Non sono presenti News per il giorno indicato");
define("LAN_NEWS_300", "Su");
define("LAN_NEWS_307", "Totale messaggi in questa categoria:");
define("LAN_NEWS_308", "Stai cercando una delle Notizie sottoelencate?");
define("LAN_NEWS_309", "Tag");
