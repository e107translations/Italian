<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_PAGE_1", "Pagina inserzione è spento");
define("LAN_PAGE_2", "Non sono presenti pagine");
define("LAN_PAGE_3", "Pagina richiesta non esiste");
define("LAN_PAGE_4", "Vota questa pagina");
define("LAN_PAGE_5", "Grazie per valutare questa pagina");
define("LAN_PAGE_6", "Non si dispone dell'autorizzazione per visualizzare questa pagina");
define("LAN_PAGE_7", "Password non corretta");
define("LAN_PAGE_8", "Pagina protetta da password");
define("LAN_PAGE_10", "Invia");
define("LAN_PAGE_11", "Pagina elenco");
define("LAN_PAGE_12", "Pagina non valida");
define("LAN_PAGE_13", "Pagina");
define("LAN_PAGE_14", "Altri articoli");
define("LAN_PAGE_15", "Articoli");
define("LAN_PAGE_16", "Non ci sono no capitoli in questo libro");
define("LAN_PAGE_17", "Non sono permessi commenti");
