<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LANMAILH_1", "Prodotta dal sistema del sito Web di e107");
define("LANMAILH_2", "Si tratta di un messaggio multiparte in formato MIME.");
define("LANMAILH_3", "non è formattato correttamente");
define("LANMAILH_4", "Indirizzo server rifiutato");
define("LANMAILH_5", "Nessuna risposta dal server");
define("LANMAILH_6", "Impossibile trovare il server di posta elettronica.");
define("LANMAILH_7", "sembra essere valido.");
