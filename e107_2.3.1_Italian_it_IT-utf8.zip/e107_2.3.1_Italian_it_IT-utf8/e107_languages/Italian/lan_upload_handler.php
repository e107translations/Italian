<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LANUPLOAD_1", "Il tipo di file");
define("LANUPLOAD_2", "non è consentito ed è stato eliminato.");
define("LANUPLOAD_3", "Caricato correttamente");
define("LANUPLOAD_4", "Una cartella di destinazione non esiste o non è scrivibile. (chmod 777)");
define("LANUPLOAD_5", "Il file caricato supera la direttiva upload_max_filesize in php. ini.");
define("LANUPLOAD_6", "Il file caricato supera la direttiva MAX_FILE_SIZE è stata specificata nel modulo html.");
define("LANUPLOAD_7", "Il file caricato è stato caricato solo parzialmente.");
define("LANUPLOAD_8", "Nessun file è stato caricato.");
define("LANUPLOAD_9", "Dimensione dei file caricati 0 byte");
define("LANUPLOAD_10", "Carica non riuscita [nome file duplicato] - esiste già un file con lo stesso nome.");
define("LANUPLOAD_11", "Non caricare il file. Nome file:");
define("LANUPLOAD_13", "Manca la cartella temporanea");
define("LANUPLOAD_14", "Scrittura di file non riuscita");
define("LANUPLOAD_15", "Caricamento non ammessi");
define("LANUPLOAD_16", "Errore sconosciuto");
define("LANUPLOAD_17", "Nome non valido per il file caricato");
define("LANUPLOAD_18", "Il file caricato supera i limiti consentiti.");
define("LANUPLOAD_19", "Troppi file caricati - eccesso eliminato.");
