<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Italian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2021/03/14 00:54:03
|
|        $Author: webmaster $
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "Reimpostazione della password");
define("LAN_02", "Siamo spiacenti, Impossibile inviare e-mail - si prega di contattare l'amministratore del sito principale.");
define("LAN_03", "Reimpostazione della password");
define("LAN_05", "Per reimpostare la password si prega di inserire le seguenti informazioni");
define("LAN_06", "Ha tentato di reimpostazione della password");
define("LAN_07", "Qualcuno con indirizzo IP");
define("LAN_08", "ha tentato di reimpostare la password dell'amministratore principale.");
define("LAN_09", "Password di ripristino da");
define("LAN_213", "Che nome utente/indirizzo e-mail non è stato trovato nel database.");
define("LAN_214", "Impossibile reimpostare la password");
define("LAN_218", "Il tuo nome utente è:");
define("LAN_FPW1", "Nome utente");
define("LAN_FPW4", "È già stata inviata una richiesta di reimpostare la password, se non hai ricevuto l'email, si prega di contattare l'amministratore del sito per aiuto.");
define("LAN_FPW5", "Una richiesta di reimpostare la password per");
define("LAN_FPW6", "Un'e-mail è stata inviata a voi con un link che vi permetterà di reimpostare la password.");
define("LAN_FPW7", "Non si tratta di un link valido per reimpostare la password.<br>Per maggiori dettagli, si prega di contattare l'amministratore del sito.");
define("LAN_FPW8", "La password è stata modificata correttamente.");
define("LAN_FPW9", "La nuova password è:");
define("LAN_FPW10", "Per favore");
define("LAN_FPW11", "entra ora");
define("LAN_FPW12", "e modificare immediatamente la password, per motivi di sicurezza.");
define("LAN_FPW13", "si prega di seguire le istruzioni nell'email per convalidare la password.");
define("LAN_FPW14", "è stato presentato da qualcuno con l'IP di");
define("LAN_FPW15", "Questo non significa che ancora è stata reimpostata la password.  È necessario passare il link indicato di seguito per completare il processo di ripristino.");
define("LAN_FPW16", "Se non hai richiesto per la password reset e non si desidera ripristinare, è possibile semplicemente ignorare questa email");
define("LAN_FPW17", "Il link qui sotto sarà valido per 48 ore.");
define("LAN_FPW18", "Richiesta di reimpostazione della password");
define("LAN_FPW19", "Invio di e-mail non riuscita");
define("LAN_FPW20", "Invio di e-mail è riuscito");
define("LAN_FPW21", "Utente ha fatto cliccati sul collegamento Reimposta password");
define("LAN_FPW22", "Indirizzo email registrato su questo sito web");
define("LAN_FPW_100", "Hai dimenticato la password?");
define("LAN_FPW_101", "Non si preoccupi. Basta inserire il tuo indirizzo email qui sotto e ti invieremo una mail di istruzioni per il recupero.");
define("LAN_FPW_102", "Reimpostare la Password");
