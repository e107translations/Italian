<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("PAGE_NAME", "Solo per i membri");
define("LAN_MEMBERS_0", "area riservata");
define("LAN_MEMBERS_1", "Si tratta di un'area riservata.");
define("LAN_MEMBERS_2", "Per l'accesso si prega di [login]");
define("LAN_MEMBERS_3", "o [registrati] come membro.");
define("LAN_MEMBERS_4", "Clicca qui per tornare alla prima pagina.");
